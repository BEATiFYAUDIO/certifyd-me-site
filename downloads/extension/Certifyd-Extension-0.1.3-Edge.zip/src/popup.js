(function (root) {
  const app = root.CertifydExtension;
  const outlet = root.document.getElementById("app");
  let localKey = null;
  let currentPage = null;

  function element(tag, text, className) {
    const node = root.document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function button(text, action, secondary = false) {
    const node = element("button", text, secondary ? "secondary" : "");
    node.type = "button";
    node.addEventListener("click", async () => {
      if (node.disabled) return;
      node.disabled = true;
      try { await action(); } catch (error) { showError(error); }
      finally { node.disabled = false; }
    });
    return node;
  }

  function link(text, url) {
    const node = element("a", text);
    node.href = url;
    node.target = "_blank";
    node.rel = "noopener noreferrer";
    return node;
  }

  function field(label, name, { multiline = false, placeholder = "", value = "", type = "text" } = {}) {
    const wrap = element("label", undefined, "field");
    const text = element("span", label);
    const input = root.document.createElement(multiline ? "textarea" : "input");
    input.name = name;
    input.value = value || "";
    input.placeholder = placeholder;
    if (!multiline) input.type = type;
    wrap.append(text, input);
    return wrap;
  }

  function formValues(form) {
    return Object.fromEntries(new root.FormData(form).entries());
  }

  function valuesFromPayload(payload = {}) {
    const slots = payload.slots || {};
    return {
      revealTitle: slots.reveal?.title || "",
      revealText: slots.reveal?.text || "",
      revealUrl: slots.reveal?.url || "",
      supportLabel: slots.support?.label || "",
      supportDestination: slots.support?.destination || "",
      actionLabel: slots.action?.label || "",
      actionUrl: slots.action?.url || ""
    };
  }

  function promotionValuesFromPayload(payload = {}) {
    const promotion = payload.slots?.promotion || {};
    return {
      promotionHeadline: promotion.active === true ? promotion.headline || "" : "",
      promotionOffer: promotion.active === true ? promotion.offer || "" : "",
      promotionDescription: promotion.active === true ? promotion.description || "" : "",
      promotionDestination: promotion.active === true ? promotion.destination || "" : ""
    };
  }


  function providerLabel(provider) {
    if (provider === "certifyd") return "sovereign profile";
    if (provider === "github") return "GitHub profile";
    if (provider === "tiktok") return "TikTok profile";
    if (provider === "youtube") return "YouTube channel";
    if (provider === "spotify") return "Spotify artist";
    return "creator page";
  }

  function providerName(provider) {
    if (provider === "certifyd") return "their sovereign profile";
    if (provider === "github") return "GitHub";
    if (provider === "tiktok") return "TikTok";
    if (provider === "youtube") return "YouTube";
    if (provider === "spotify") return "Spotify";
    return provider ? provider.charAt(0).toUpperCase() + provider.slice(1) : "this site";
  }

  const POPUP_MODES = Object.freeze({
    CREATOR_AUTHORIZED: "creator_authorized",
    VERIFIED_PAGE_UNAUTHORIZED: "verified_page_unauthorized",
    NO_VERIFIED_CREATOR: "no_verified_creator"
  });

  function popupMode(page, key, connected) {
    if (page?.status !== "verified") return POPUP_MODES.NO_VERIFIED_CREATOR;
    return key?.publicKey && connected === true
      ? POPUP_MODES.CREATOR_AUTHORIZED
      : POPUP_MODES.VERIFIED_PAGE_UNAUTHORIZED;
  }

  function reset() { outlet.replaceChildren(); }
  function showError(error) { outlet.append(element("p", error?.message || "Something went wrong.", "notice")); }

  function sendToActiveTab(message) {
    const browserApi = root.browser || root.chrome;
    if (!browserApi?.tabs) return Promise.resolve({ status: "unavailable" });
    if (root.browser?.tabs) {
      return root.browser.tabs.query({ active: true, currentWindow: true })
        .then((tabs) => tabs[0]?.id === undefined ? null : root.browser.tabs.sendMessage(tabs[0].id, message))
        .catch(() => ({ status: "unavailable" }));
    }
    return new Promise((resolve) => {
      browserApi.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (browserApi.runtime.lastError || tabs?.[0]?.id === undefined) return resolve({ status: "unavailable" });
        browserApi.tabs.sendMessage(tabs[0].id, message, (result) =>
          resolve(browserApi.runtime.lastError ? { status: "unavailable" } : result || { status: "unavailable" }));
      });
    });
  }

  function activeTab() {
    const browserApi = root.browser || root.chrome;
    if (!browserApi?.tabs) return Promise.resolve(null);
    if (root.browser?.tabs) {
      return root.browser.tabs.query({ active: true, currentWindow: true })
        .then((tabs) => tabs?.[0] || null)
        .catch(() => null);
    }
    return new Promise((resolve) => {
      browserApi.tabs.query({ active: true, currentWindow: true }, (tabs) =>
        resolve(browserApi.runtime?.lastError ? null : tabs?.[0] || null));
    });
  }

  function isCertifydFanUrl(value) {
    try {
      const url = new root.URL(value);
      return url.protocol === "https:" && url.hostname === "fan.certifyd.me" && (!url.port || url.port === "443");
    } catch {
      return false;
    }
  }

  async function sovereignPageFromActiveTab(tab = null) {
    tab ||= await activeTab();
    const profile = await app.network?.resolveProfileReference?.(tab?.url, root.fetch?.bind(root));
    if (!profile) return null;
    const response = await app.network?.fetchProofBundle?.(profile, root.fetch?.bind(root));
    if (!response?.ok) return { status: "unavailable", pageKind: "sovereign" };
    const result = app.certifyd.compareSovereignProfile({ profileUrl: profile.profileUrl, bundle: response.bundle });
    if (result.status !== "core_reports_verified") return { status: "unverified", pageKind: "sovereign" };
    const profileAssets = await app.network.fetchProfileAssets?.(profile, root.fetch?.bind(root)).catch(() => ({}));
    return {
      status: "verified",
      pageKind: "sovereign",
      externalIdentity: result.externalIdentity,
      profileUrl: profile.profileUrl,
      bundle: response.bundle,
      profileAssets
    };
  }

  async function activePage() {
    const tab = await activeTab();
    if (isCertifydFanUrl(tab?.url)) return { status: "fan_promotion", pageKind: "fan" };
    const page = await sendToActiveTab({ type: "CERTIFYD_REFRESH_PAGE" });
    if (page?.status !== "unavailable") return page;
    return await sovereignPageFromActiveTab(tab) || page;
  }

  function renderFanProfileCard(page, target) {
    const bundle = page.bundle;
    const card = element("section", undefined, "fan-profile-card");
    const wallpaperUrl = page.profileAssets?.wallpaperUrl;
    if (wallpaperUrl) card.style?.setProperty?.("--creator-wallpaper", `url("${wallpaperUrl.replace(/"/g, "%22")}")`);
    const hero = element("div", undefined, "fan-profile-hero");
    const avatarUrl = page.profileAssets?.avatarUrl;
    const mark = root.document.createElement("img");
    mark.className = avatarUrl ? "fan-profile-avatar" : "fan-profile-mark";
    mark.src = avatarUrl || "icons/certifyd-mark-32.png";
    mark.alt = avatarUrl ? `${bundle.displayName || "Creator"} avatar` : "";
    if (!avatarUrl) mark.setAttribute("aria-hidden", "true");
    const identity = element("div", undefined, "fan-profile-identity");
    identity.append(element("span", "Certifyd profile", "fan-profile-kicker"));
    identity.append(element("h2", bundle.displayName || "Certifyd creator", "creator-name"));
    identity.append(element("p", "Verified on Certifyd", "status"));
    hero.append(mark, identity);
    card.append(hero);

    const summary = element("div", undefined, "fan-profile-summary");
    summary.append(element("p", page.pageKind === "sovereign"
      ? "This is the creator's verified sovereign Certifyd profile."
      : `This ${providerLabel(page.externalIdentity?.provider)} is linked to a Certifyd profile.`, "muted"));
    summary.append(link("Open Certifyd profile", page.profileUrl));
    card.append(summary);

    const domains = Array.isArray(bundle.proofs?.domains) ? bundle.proofs.domains : [];
    const verifiedDomains = domains.filter((item) => item?.domain && item.verifiedAt);
    if (verifiedDomains.length) {
      const section = element("section", undefined, "fan-proof-section");
      section.append(element("h2", "Verified websites"));
      const list = element("div", undefined, "fan-proof-list");
      for (const item of verifiedDomains) {
        const domain = String(item.domain);
        if (!/^[a-z0-9.-]+$/i.test(domain)) continue;
        const chip = element("span", undefined, "fan-proof-chip");
        chip.append(element("span", "✓", "fan-proof-icon"));
        chip.append(link(domain, `https://${domain}`));
        list.append(chip);
      }
      section.append(list);
      card.append(section);
    }

    const social = Array.isArray(bundle.proofs?.social) ? bundle.proofs.social : [];
    const verifiedSocial = social.filter((item) => item?.provider && item.account && item.verifiedAt);
    if (verifiedSocial.length) {
      const section = element("section", undefined, "fan-proof-section");
      section.append(element("h2", "Verified accounts"));
      const list = element("div", undefined, "fan-proof-list");
      for (const item of verifiedSocial) {
        const chip = element("span", undefined, "fan-proof-chip");
        chip.append(element("span", String(item.provider).slice(0, 1).toUpperCase(), "fan-proof-icon"));
        const label = `${item.provider}: ${item.account}`;
        let linked = false;
        if (typeof item.location === "string") {
          try {
            const url = new URL(item.location);
            if (url.protocol === "https:") {
              chip.append(link(label, url.href));
              linked = true;
            }
          } catch {}
        }
        if (!linked) chip.append(element("span", label));
        list.append(chip);
      }
      section.append(list);
      card.append(section);
    }
    target.append(card);
  }

  async function liveConnectedPage() {
    const fresh = await activePage();
    if (fresh?.status !== "verified" || !localKey) return { page: fresh, connected: false };
    const connected = await app.ar.verifyConnection({ bundle: fresh.bundle, profileUrl: fresh.profileUrl, publicKey: localKey.publicKey });
    return { page: fresh, connected };
  }

  function renderInvitationCard(page) {
    reset();
    const primary = element("section", undefined, "primary primary--fan");
    const card = element("section", undefined, "invitation-card");
    card.append(element("span", "Invite a creator", "invitation-card__eyebrow"));
    card.append(element("h1", "Bring this creator to Certifyd"));
    card.append(element("p", `This ${providerLabel(page.externalIdentity?.provider)} is not linked to a verified Certifyd creator yet.`));
    card.append(element("p", "Introduce them to creator-owned profiles, verified identity, and direct fan experiences.", "muted"));
    const learn = link("Learn about Certifyd", "https://certifyd.me/");
    learn.className = "invitation-card__action";
    card.append(learn);
    card.append(button("Copy invitation", async () => {
      await root.navigator?.clipboard?.writeText?.("I found your profile and would love to see you on Certifyd: https://certifyd.me/");
      card.append(element("p", "Invitation copied.", "status"));
    }, true));
    primary.append(card);
    outlet.append(primary);
  }

  function renderCertifydFanPromotion() {
    reset();
    const primary = element("section", undefined, "primary primary--fan");
    const card = element("section", undefined, "invitation-card fan-promotion-card");
    card.append(element("span", "Certifyd", "invitation-card__eyebrow"));
    card.append(element("h1", "Your identity. Your content. Your world."));
    card.append(element("p", "Discover what creators can do when they own their identity, content, and connections."));
    const discover = link("Discover Certifyd", "https://certifyd.me");
    discover.className = "invitation-card__action";
    card.append(discover);
    primary.append(card);
    outlet.append(primary);
  }

  function renderConnectionSection(page, { revealCode = false, message = "" } = {}) {
    const controls = element("section", undefined, "controls connection-controls");
    controls.append(element("h2", "Connection options"));
    controls.append(element("p", "This is a verified Certifyd creator page.", "muted"));

    if (message) controls.append(element("p", message, "status"));

    if (!localKey) {
      controls.append(button("Connect this browser", async () => {
        localKey = await app.arKey.createKey(page.profileUrl);
        reset();
        const primary = element("section", undefined, "primary primary--fan");
        renderFanProfileCard(page, primary);
        outlet.append(primary);
        outlet.append(renderConnectionSection(page, { revealCode: true, message: "Connection code ready." }));
      }));
      controls.append(button("Check connection", refresh, true));
      return controls;
    }

    if (!revealCode) {
      controls.append(button("Connect this browser", async () => {
        reset();
        const primary = element("section", undefined, "primary primary--fan");
        renderFanProfileCard(page, primary);
        outlet.append(primary);
        outlet.append(renderConnectionSection(page, { revealCode: true }));
      }));
      controls.append(button("Check connection", refresh, true));
      controls.append(button("Reset this device", async () => {
        if (root.confirm && !root.confirm("Reset this Certifyd AR connection?\n\nThis will create a new connection code for this browser. Your old Certifyd AR connection will no longer be used by this extension.")) return;
        localKey = await app.arKey.resetKey(page.profileUrl);
        reset();
        const primary = element("section", undefined, "primary primary--fan");
        renderFanProfileCard(page, primary);
        outlet.append(primary);
        outlet.append(renderConnectionSection(page, { revealCode: true, message: "New connection code ready." }));
      }, true));
      return controls;
    }

    controls.append(element("p", "Connection code from Certifyd AR", "muted"));
    controls.append(element("pre", localKey.publicKey, "code"));
    controls.append(button("Copy code", async () => {
      await root.navigator?.clipboard?.writeText?.(localKey.publicKey);
    }, true));
    controls.append(button("Check connection", refresh, true));
    controls.append(button("Reset this device", async () => {
      if (root.confirm && !root.confirm("Reset this Certifyd AR connection?\n\nThis will create a new connection code for this browser. Your old Certifyd AR connection will no longer be used by this extension.")) return;
      localKey = await app.arKey.resetKey(page.profileUrl);
      reset();
      const primary = element("section", undefined, "primary primary--fan");
      renderFanProfileCard(page, primary);
      outlet.append(primary);
      outlet.append(renderConnectionSection(page, { revealCode: true, message: "New connection code ready." }));
    }, true));
    controls.append(element("p", "Approve this code in Core, then check connection.", "muted"));
    return controls;
  }

  async function renderCreatorEditor(page, connected) {
    reset();
    const saved = await app.arRecord.loadVerified(page, { currentPublicKey: localKey.publicKey });
    const values = valuesFromPayload(saved?.payload);
    const context = element("section", undefined, "context");
    context.append(element("h1", "Certifyd AR"), element("p", "Connected ✓", "status"));
    context.append(element("p", `Current page: ${page.bundle.displayName || "Creator"} on ${providerName(page.externalIdentity?.provider)}`, "muted"));
    const primary = element("section", undefined, "primary");
    primary.append(element("p", "This is your verified page."));
    const form = element("form", undefined, "editor");
    form.append(element("h2", "Reveal"));
    form.append(field("Title", "revealTitle", { placeholder: "Secret show", value: values.revealTitle }));
    form.append(field("Text", "revealText", { multiline: true, placeholder: "Secret show Friday night", value: values.revealText }));
    form.append(field("Link", "revealUrl", { placeholder: "https://example.com/secret-show", value: values.revealUrl }));
    form.append(element("h2", "Support"));
    form.append(field("Label", "supportLabel", { placeholder: "Send sats", value: values.supportLabel }));
    form.append(field("Destination", "supportDestination", { placeholder: "name@example.com, BTC address, or https://...", value: values.supportDestination }));
    form.append(element("h2", "Action"));
    form.append(field("Label", "actionLabel", { placeholder: "Get tickets", value: values.actionLabel }));
    form.append(field("Destination", "actionUrl", { placeholder: "https://example.com/tickets", value: values.actionUrl }));
    const preview = element("div", undefined, "preview");
    const actions = element("div", undefined, "editor-actions");
    actions.append(button("Save", async () => {
      const live = await liveConnectedPage();
      if (!live.connected) {
        await renderPage(live.page || page);
        throw new Error("Reconnect this device before saving AR updates.");
      }
      let publicRecord = null;
      if (app.arTransportStatic?.loadVerifiedPublicRecord && root.fetch) {
        try {
          publicRecord = await app.arTransportStatic.loadVerifiedPublicRecord(live.page, {
            fetcher: root.fetch.bind(root)
          });
        } catch {}
      }
      const publicSequence = publicRecord?.payload?.sequence;
      const envelope = await app.arRecord.saveRecord({
        page: live.page,
        input: formValues(form),
        key: localKey,
        connected: live.connected,
        minimumSequence: Number.isSafeInteger(publicSequence) ? publicSequence + 1 : undefined
      });
      await sendToActiveTab({ type: "CERTIFYD_REFRESH_PAGE" });
      await renderPage(live.page);
      outlet.append(element("p", `Saved ${app.arRecord.slotCount(envelope.payload)} AR slot${app.arRecord.slotCount(envelope.payload) === 1 ? "" : "s"}.`, "notice"));
    }));
    actions.append(button("Preview as fan", async () => {
      preview.replaceChildren();
      preview.className = "preview";
      try {
        const payload = app.arRecord.buildPayload({
          profileUrl: page.profileUrl,
          bundle: page.bundle,
          externalIdentity: page.externalIdentity,
          input: formValues(form),
          sequence: saved?.payload?.sequence || 1
        });
        app.ui.renderButtonArPanel(root.document, preview, {
          creatorName: page.bundle.displayName || "Creator",
          payload,
          profileAssets: page.profileAssets
        });
      } catch (error) {
        preview.append(element("p", error?.message || "Preview could not be rendered.", "notice"));
      }
    }, true));
    const publishStatus = element("p", "", "muted");
    const publishButton = button("Publish", async () => {
      publishStatus.textContent = "Publishing...";
      publishStatus.className = "muted";
      const live = await liveConnectedPage();
      if (!live.connected) {
        await renderPage(live.page || page);
        throw new Error("Not connected");
      }
      const latest = await app.arRecord.loadVerified(live.page, { currentPublicKey: localKey.publicKey });
      if (!latest) throw new Error("Save AR before publishing.");
      try {
        await app.arTransportStatic.publishRecord({ page: live.page, envelope: latest });
        await sendToActiveTab({ type: "CERTIFYD_REFRESH_PAGE" });
        publishStatus.textContent = "Published";
        publishStatus.className = "status";
      } catch (error) {
        publishStatus.textContent = "Publish failed";
        publishStatus.className = "notice";
        throw error;
      }
    });
    const publishEndpointConfigured = Boolean(app.arTransportStatic?.configuredPublishEndpoint?.());
    publishButton.disabled = !saved || !publishEndpointConfigured;
    actions.append(publishButton);
    form.append(actions);
    const publish = element("section", undefined, "publish");
    publish.append(element("h2", "Public AR"));
    if (!saved) publishStatus.textContent = "Save locally before publishing.";
    else if (!publishEndpointConfigured) publishStatus.textContent = "Publishing is not connected yet.";
    else publishStatus.textContent = "Ready to publish.";
    publish.append(publishStatus);
    primary.append(form, preview, publish);
    const controls = element("section", undefined, "controls");
    controls.append(element("h2", "Connection options"), button("Check connection", refresh, true));
    outlet.append(context, primary, controls);
  }

  async function publicSequenceFor(page) {
    if (!app.arTransportStatic?.loadVerifiedPublicRecord || !root.fetch) return undefined;
    try {
      const record = await app.arTransportStatic.loadVerifiedPublicRecord(page, { fetcher: root.fetch.bind(root) });
      return Number.isSafeInteger(record?.payload?.sequence) ? record.payload.sequence : undefined;
    } catch {
      return undefined;
    }
  }

  async function renderPromotionEditor(page) {
    reset();
    const saved = await app.arRecord.loadVerified(page, { currentPublicKey: localKey.publicKey });
    const values = promotionValuesFromPayload(saved?.payload);
    const context = element("section", undefined, "context");
    context.append(element("h1", "Certifyd AR"), element("p", "Connected ✓", "status"));
    context.append(element("p", `Sovereign profile: ${page.bundle.displayName || page.externalIdentity.account}`, "muted"));
    const primary = element("section", undefined, "primary");
    const form = element("form", undefined, "editor promotion-editor");
    form.append(element("h2", "Profile promotion"));
    form.append(field("Headline", "promotionHeadline", { placeholder: "A release, special, or reward", value: values.promotionHeadline }));
    form.append(field("Offer", "promotionOffer", { placeholder: "Listen now, Claim reward, Save 20%", value: values.promotionOffer }));
    form.append(field("Description", "promotionDescription", { multiline: true, placeholder: "Tell fans what is available and why it matters.", value: values.promotionDescription }));
    form.append(field("Destination", "promotionDestination", { placeholder: "https://...", value: values.promotionDestination, type: "url" }));
    const preview = element("div", undefined, "preview promotion-wrap");
    const actions = element("div", undefined, "editor-actions");
    actions.append(button("Save", async () => {
      const live = await liveConnectedPage();
      if (!live.connected) {
        await renderPage(live.page || page);
        throw new Error("Reconnect this device before saving AR updates.");
      }
      const publicSequence = await publicSequenceFor(live.page);
      const envelope = await app.arRecord.saveRecord({
        page: live.page,
        input: { ...formValues(form), promotionActive: true },
        key: localKey,
        connected: true,
        minimumSequence: Number.isSafeInteger(publicSequence) ? publicSequence + 1 : undefined
      });
      await renderPage(live.page);
      outlet.append(element("p", `Saved promotion sequence ${envelope.payload.sequence}.`, "notice"));
    }));
    actions.append(button("Preview as fan", async () => {
      preview.replaceChildren();
      try {
        const payload = app.arRecord.buildPayload({
          profileUrl: page.profileUrl,
          bundle: page.bundle,
          externalIdentity: page.externalIdentity,
          input: { ...formValues(form), promotionActive: true },
          sequence: saved?.payload?.sequence || 1
        });
        if (!app.ui.renderPromotionCard(root.document, preview, {
          creatorName: page.bundle.displayName || "Creator",
          payload,
          profileAssets: page.profileAssets
        })) throw new Error("Promotion could not be previewed.");
      } catch (error) {
        preview.append(element("p", error?.message || "Preview could not be rendered.", "notice"));
      }
    }, true));
    const publishStatus = element("p", saved ? "Ready to publish." : "Save locally before publishing.", "promotion-status muted");
    const publishButton = button("Publish", async () => {
      publishStatus.textContent = "Publishing…";
      const live = await liveConnectedPage();
      if (!live.connected) throw new Error("Not connected");
      const latest = await app.arRecord.loadVerified(live.page, { currentPublicKey: localKey.publicKey });
      if (!latest || !app.arRecord.isUsablePromotion(latest.payload)) throw new Error("Save the promotion before publishing.");
      await app.arTransportStatic.publishRecord({ page: live.page, envelope: latest });
      publishStatus.textContent = "Published";
      publishStatus.className = "promotion-status status";
    });
    publishButton.disabled = !saved || !app.arRecord.isUsablePromotion(saved.payload) || !app.arTransportStatic?.configuredPublishEndpoint?.();
    actions.append(publishButton);
    actions.append(button("Deactivate", async () => {
      if (root.confirm && !root.confirm("Deactivate this public profile promotion?")) return;
      const live = await liveConnectedPage();
      if (!live.connected) throw new Error("Not connected");
      const publicSequence = await publicSequenceFor(live.page);
      const inactive = await app.arRecord.saveRecord({
        page: live.page,
        input: { promotionActive: false },
        key: localKey,
        connected: true,
        minimumSequence: Number.isSafeInteger(publicSequence) ? publicSequence + 1 : undefined
      });
      await app.arTransportStatic.publishRecord({ page: live.page, envelope: inactive });
      await renderPage(live.page);
      outlet.append(element("p", "Promotion deactivated.", "notice"));
    }, true));
    form.append(actions, publishStatus);
    primary.append(form, preview);
    const controls = element("section", undefined, "controls");
    controls.append(element("h2", "Connection options"), button("Check connection", refresh, true));
    outlet.append(context, primary, controls);
  }


  async function renderPage(page) {
    currentPage = page;
    if (page?.status === "fan_promotion") return renderCertifydFanPromotion();
    if (page?.status !== "verified") {
      if (page?.status === "unregistered" && page.pageKind === "supported_social" && page.externalIdentity) {
        return renderInvitationCard(page);
      }
      reset();
      outlet.append(element("h1", "Certifyd AR"));
      outlet.append(element("p", page?.status === "unavailable"
        ? "Could not check this page. Open a verified supported creator page and try again."
        : "Open a verified supported creator page to see its Certifyd profile.", "muted"));
      outlet.append(button("Try again", refresh, true));
      return;
    }
    const connected = localKey?.publicKey
      ? await app.ar.verifyConnection({ bundle: page.bundle, profileUrl: page.profileUrl, publicKey: localKey.publicKey })
      : false;
    const mode = popupMode(page, localKey, connected);
    if (mode === POPUP_MODES.CREATOR_AUTHORIZED) {
      return page.pageKind === "sovereign" ? renderPromotionEditor(page) : renderCreatorEditor(page, connected);
    }
    reset();
    const primary = element("section", undefined, "primary primary--fan");
    if (page.pageKind === "sovereign") {
      const record = await app.arTransportStatic?.loadVerifiedPublicRecord?.(page, { fetcher: root.fetch?.bind(root) }).catch(() => null);
      if (record && app.arRecord.isUsablePromotion(record.payload)) {
        const promotion = element("section", undefined, "promotion-wrap");
        app.ui.renderPromotionCard(root.document, promotion, {
          creatorName: page.bundle.displayName || "Creator",
          payload: record.payload,
          profileAssets: page.profileAssets
        });
        primary.append(promotion);
      }
    }
    renderFanProfileCard(page, primary);
    outlet.append(primary, renderConnectionSection(page));
  }

  async function refresh() {
    reset();
    outlet.append(element("p", "Checking this page…", "muted"));
    const page = await activePage();
    await renderPage(page || { status: "unavailable" });
  }

  app.arKey.getKey().then((key) => { localKey = key; return refresh(); }, showError);
})(globalThis);
