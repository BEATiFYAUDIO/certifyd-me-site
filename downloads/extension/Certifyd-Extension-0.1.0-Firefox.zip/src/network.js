(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function isPublicHttpsNode(profile) {
    if (!profile) return false;
    try {
      const url = new URL(profile.nodeUrl);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.port && host.includes(".") &&
        !host.endsWith(".local") && !host.endsWith(".localhost") &&
        !/^\d+(?:\.\d+){3}$/.test(host) && !host.includes(":");
    } catch {
      return false;
    }
  }

  function resolveProfileLinkFromHtml(html, nodeUrl) {
    if (typeof html !== "string") return null;
    let origin;
    try { origin = new URL(nodeUrl).origin; } catch { return null; }
    const patterns = [
      /https:\/\/[^\s"'<>]+\/u\/([a-z0-9][a-z0-9_-]{0,63})\/proofs\.json/ig,
      /https:\/\/[^\s"'<>]+\/u\/([a-z0-9][a-z0-9_-]{0,63})\/?/ig,
      /\/u\/([a-z0-9][a-z0-9_-]{0,63})\/proofs\.json/ig,
      /\/u\/([a-z0-9][a-z0-9_-]{0,63})\/?/ig
    ];
    for (const pattern of patterns) {
      for (const match of html.matchAll(pattern)) {
        const raw = match[0].startsWith("http") ? match[0] : `${origin}${match[0]}`;
        try {
          const url = new URL(raw);
          if (url.origin !== origin) continue;
          const parsed = app.certifyd?.parseProfileUrl(`${origin}/u/${match[1]}`);
          if (parsed) return parsed;
        } catch {}
      }
    }
    return null;
  }

  async function resolveProfileReference(value, fetcher = root.fetch, signal) {
    const direct = app.certifyd?.parseProfileUrl(value);
    if (direct) return direct;
    const rootRef = app.certifyd?.parseNodeRootUrl?.(value);
    if (!rootRef || !isPublicHttpsNode({ nodeUrl: rootRef.nodeUrl }) || typeof fetcher !== "function") return null;
    try {
      const response = await fetcher(rootRef.nodeUrl, {
        method: "GET",
        mode: "cors",
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal,
        headers: { accept: "text/html" }
      });
      if (!response.ok || new URL(response.url || rootRef.nodeUrl).origin !== rootRef.nodeUrl ||
          !/^text\/html\b/i.test(response.headers?.get?.("content-type") || "")) return null;
      const length = Number(response.headers?.get?.("content-length") || 0);
      if (length > 2000000) return null;
      const text = await response.text();
      if (text.length > 2000000) return null;
      return resolveProfileLinkFromHtml(text, rootRef.nodeUrl);
    } catch {
      return null;
    }
  }

  async function fetchProofBundle(profile, fetcher = root.fetch, signal) {
    if (!isPublicHttpsNode(profile) || typeof fetcher !== "function") {
      return { ok: false, reason: "invalid_node" };
    }
    try {
      const response = await fetcher(profile.proofsUrl, {
        method: "GET",
        mode: "cors",
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal,
        headers: { accept: "application/json" }
      });
      if (!response.ok || response.url !== profile.proofsUrl ||
          !/^application\/json\b/i.test(response.headers.get("content-type") || "")) {
        return { ok: false, reason: "invalid_response" };
      }
      const length = Number(response.headers.get("content-length") || 0);
      if (length > 512000) return { ok: false, reason: "oversized_response" };
      const text = await response.text();
      if (text.length > 512000) return { ok: false, reason: "oversized_response" };
      return { ok: true, bundle: JSON.parse(text) };
    } catch {
      return { ok: false, reason: "fetch_failed" };
    }
  }


  function resolvePublicAssetUrl(value, profileUrl) {
    if (typeof value !== "string" || !value.trim()) return null;
    try {
      const base = new URL(profileUrl);
      const url = new URL(value, base);
      if (url.protocol !== "https:" || url.origin !== base.origin) return null;
      if (!/^\/public\/(?:profile-wallpapers|avatars|content)\//.test(url.pathname)) return null;
      url.hash = "";
      return url.href;
    } catch {
      return null;
    }
  }

  function parseProfileAssets(html, profileUrl) {
    if (typeof html !== "string") return {};
    const wallpaperMatch = /background\s*:\s*url\((?:"([^"]+)"|'([^']+)'|([^\)]+))\)/i.exec(html);
    const avatarMatch = /<img\b[^>]*\bsrc=["']([^"']*\/public\/avatars\/[^"']+)["'][^>]*>/i.exec(html);
    const featuredMatch = /<img\b[^>]*\bsrc=["']([^"']+)["'][^>]*\bclass=["'][^"']*featured-image[^"']*["'][^>]*>/i.exec(html) ||
      /<img\b[^>]*\bclass=["'][^"']*featured-image[^"']*["'][^>]*\bsrc=["']([^"']+)["'][^>]*>/i.exec(html);
    const wallpaperUrl = resolvePublicAssetUrl(wallpaperMatch?.[1] || wallpaperMatch?.[2] || wallpaperMatch?.[3], profileUrl);
    const avatarUrl = resolvePublicAssetUrl(avatarMatch?.[1], profileUrl);
    let featuredImageUrl = null;
    if (featuredMatch?.[1]) {
      try {
        const url = new URL(featuredMatch[1], profileUrl);
        if (url.protocol === "https:") {
          url.hash = "";
          featuredImageUrl = url.href;
        }
      } catch {}
    }
    return { wallpaperUrl, avatarUrl, featuredImageUrl };
  }

  async function fetchProfileAssets(profile, fetcher = root.fetch, signal) {
    if (!isPublicHttpsNode(profile) || typeof fetcher !== "function") return {};
    try {
      const response = await fetcher(profile.profileUrl, {
        method: "GET",
        mode: "cors",
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal,
        headers: { accept: "text/html" }
      });
      if (!response.ok || response.url !== profile.profileUrl ||
          !/^text\/html\b/i.test(response.headers.get("content-type") || "")) {
        return {};
      }
      const length = Number(response.headers.get("content-length") || 0);
      if (length > 2000000) return {};
      const text = await response.text();
      if (text.length > 2000000) return {};
      return parseProfileAssets(text, profile.profileUrl);
    } catch {
      return {};
    }
  }

  app.network = { isPublicHttpsNode, resolveProfileLinkFromHtml, resolveProfileReference, fetchProofBundle, parseProfileAssets, fetchProfileAssets };
  if (typeof module !== "undefined" && module.exports) module.exports = app.network;
})(globalThis);
