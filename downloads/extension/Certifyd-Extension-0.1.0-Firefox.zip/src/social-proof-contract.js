(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  const SPEC = Object.freeze({
    spotify: { canonical: "certifyd-proof provider=spotify account=<account> nonce=<nonce> profile=<profile-url>", noncePattern: /^[0-9a-f]{32}$/i },
    youtube: { canonical: "certifyd-proof provider=youtube account=<account> nonce=<nonce> profile=<profile-url>" },
    github: { canonical: "certifyd-proof provider=github account=<account> nonce=<nonce> profile=<profile-url>" },
    tiktok: { canonical: "certifyd-proof provider=tiktok account=<account> nonce=<nonce> profile=<profile-url>" }
  });

  function compact(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function normalizeAccount(provider, value) {
    const text = String(value || "").trim().replace(/^@+/, "");
    if (provider === "spotify") return /^[A-Za-z0-9]{10,64}$/.test(text) ? text : null;
    if (provider === "github") return /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(text) ? text.toLowerCase() : null;
    if (provider === "youtube") return /^[A-Za-z0-9._-]{3,64}$/.test(text) ? text.toLowerCase() : null;
    if (provider === "tiktok") return /^[A-Za-z0-9._]{2,24}$/.test(text) ? text.toLowerCase() : null;
    return null;
  }

  function normalizeProvider(value) {
    const provider = String(value || "").trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(SPEC, provider) ? provider : null;
  }

  function parseProfileReference(value) {
    const parsed = app.certifyd?.parseProfileUrl?.(value);
    return parsed?.profileUrl || null;
  }

  function parseEnvelopeFields(source) {
    const marker = /(?:^|\s)certifyd-proof(?=\s|$)/i.exec(source);
    if (!marker) return null;
    const tail = source.slice(marker.index).trim();
    const tokens = tail.split(/\s+/).filter(Boolean);
    if (!/^certifyd-proof$/i.test(tokens[0] || "")) return null;
    const fields = {};
    for (const token of tokens.slice(1)) {
      const match = /^([A-Za-z][A-Za-z0-9_-]*)=(\S+)$/.exec(token);
      if (!match) break;
      const key = match[1].toLowerCase();
      if (Object.prototype.hasOwnProperty.call(fields, key)) return null;
      fields[key] = match[2];
      if (fields.provider && fields.account && fields.nonce && fields.profile) break;
    }
    return fields.provider && fields.account && fields.nonce && fields.profile ? fields : null;
  }

  function parseCanonicalEnvelope(provider, text) {
    const expectedProvider = normalizeProvider(provider);
    if (!expectedProvider) return null;
    const source = compact(text);
    if (!source) return null;
    const fields = parseEnvelopeFields(source);
    if (!fields) return null;
    const actualProvider = normalizeProvider(fields.provider);
    if (actualProvider !== expectedProvider) return null;
    const account = normalizeAccount(actualProvider, fields.account);
    const nonce = String(fields.nonce || "").trim().toLowerCase();
    const profileUrl = parseProfileReference(fields.profile);
    if (!account || !/^[0-9a-f]{32}$/.test(nonce) || !profileUrl) return null;
    const marker = `certifyd-proof provider=${actualProvider} account=${account} nonce=${nonce} profile=${profileUrl}`;
    return { provider: actualProvider, account, nonce, profileUrl, marker, format: "canonical-envelope" };
  }

  function findCanonicalMarker(provider, text) {
    const canonical = parseCanonicalEnvelope(provider, text);
    if (canonical) return canonical;

    const source = compact(text);
    if (!source) return null;

    if (provider === "spotify") {
      const match = /(?:^|\s)Certifyd proof:\s*([0-9a-f]{32})(?=\s|$)/i.exec(source);
      if (!match) return null;
      const nonce = match[1].toLowerCase();
      return { provider, account: null, nonce, marker: `Certifyd proof: ${nonce}`, format: "spotify-proof" };
    }

    if (provider === "tiktok") {
      const short = /(?:^|\s)certifyd-proof\s+account=([^\s]+)\s+nonce=([^\s]+)(?=\s|$)/i.exec(source);
      if (short) {
        const account = normalizeAccount(provider, short[1]);
        const nonce = String(short[2] || "").trim();
        if (!account || !nonce) return null;
        return { provider, account, nonce, marker: `certifyd-proof account=${account} nonce=${nonce}`, format: "tiktok-short" };
      }
    }

    const full = new RegExp(`(?:^|\\s)certifyd-proof\\s+provider=${provider}\\s+account=([^\\s]+)\\s+nonce=([^\\s]+)(?=\\s|$)`, "i").exec(source);
    if (full) {
      const account = normalizeAccount(provider, full[1]);
      const nonce = String(full[2] || "").trim();
      if (!account || !nonce) return null;
      return { provider, account, nonce, marker: `certifyd-proof provider=${provider} account=${account} nonce=${nonce}`, format: "full" };
    }

    if ((provider === "github" || provider === "tiktok") && /(?:^|\s)certifyd-proof\s+provider=/i.test(source)) return null;
    return null;
  }

  function generatedMarker(provider, account, nonce, profileUrl) {
    const normalized = normalizeAccount(provider, account);
    const token = String(nonce || "").trim().toLowerCase();
    const profile = parseProfileReference(profileUrl);
    if (provider !== "spotify" && !normalized) return null;
    if (!token) return null;
    if (profile) {
      if (!normalized) return null;
      return `certifyd-proof provider=${provider} account=${normalized} nonce=${token} profile=${profile}`;
    }
    if (provider === "spotify") return `Certifyd proof: ${token}`;
    if (provider === "tiktok") return `certifyd-proof account=${normalized} nonce=${token}`;
    if (provider === "youtube" || provider === "github") return `certifyd-proof provider=${provider} account=${normalized} nonce=${token}`;
    return null;
  }

  app.socialProofContract = { SPEC, compact, normalizeAccount, parseCanonicalEnvelope, findCanonicalMarker, generatedMarker };
  if (typeof module !== "undefined" && module.exports) module.exports = app.socialProofContract;
})(globalThis);
