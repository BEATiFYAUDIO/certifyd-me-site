(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  const SPEC = Object.freeze({
    spotify: { canonical: "Certifyd proof: <nonce>", noncePattern: /^[0-9a-f]{32}$/i },
    youtube: { canonical: "certifyd-proof provider=youtube account=<account> nonce=<nonce>" },
    github: { canonical: "certifyd-proof provider=github account=<account> nonce=<nonce>" },
    tiktok: { canonical: "certifyd-proof account=<account> nonce=<nonce>", maxLength: 80 }
  });

  function compact(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function normalizeAccount(provider, value) {
    const text = String(value || "").trim().replace(/^@+/, "");
    if (provider === "spotify") return /^[A-Za-z0-9]{10,64}$/.test(text) ? text : null;
    if (provider === "github") return /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(text) ? text.toLowerCase() : null;
    if (provider === "youtube") return /^[A-Za-z0-9._-]{3,64}$/.test(text) ? text.toLowerCase() : null;
    if (provider === "tiktok") return /^[A-Za-z0-9._]{2,24}$/.test(text) ? text.toLowerCase() : null;
    return null;
  }

  function findCanonicalMarker(provider, text) {
    const source = compact(text);
    if (!source) return null;

    if (provider === "spotify") {
      const match = /(?:^|\s)Certifyd proof:\s*([0-9a-f]{32})(?=\s|$)/i.exec(source);
      if (!match) return null;
      const nonce = match[1].toLowerCase();
      return { provider, account: null, nonce, marker: `Certifyd proof: ${nonce}`, format: "spotify-proof" };
    }

    if (provider === "tiktok") {
      const short = /(?:^|\s)certifyd-proof\s+account=([^\s]+)\s+nonce=([^\s]+)(?=\s|$)/i.exec(source);
      if (short) {
        const account = normalizeAccount(provider, short[1]);
        const nonce = String(short[2] || "").trim();
        if (!account || !nonce) return null;
        return { provider, account, nonce, marker: `certifyd-proof account=${account} nonce=${nonce}`, format: "tiktok-short" };
      }
    }

    const full = new RegExp(`(?:^|\\s)certifyd-proof\\s+provider=${provider}\\s+account=([^\\s]+)\\s+nonce=([^\\s]+)(?=\\s|$)`, "i").exec(source);
    if (full) {
      const account = normalizeAccount(provider, full[1]);
      const nonce = String(full[2] || "").trim();
      if (!account || !nonce) return null;
      return { provider, account, nonce, marker: `certifyd-proof provider=${provider} account=${account} nonce=${nonce}`, format: "full" };
    }

    if ((provider === "github" || provider === "tiktok") && /(?:^|\s)certifyd-proof\s+provider=/i.test(source)) return null;
    return null;
  }

  function generatedMarker(provider, account, nonce) {
    const normalized = normalizeAccount(provider, account);
    const token = String(nonce || "").trim();
    if (provider !== "spotify" && !normalized) return null;
    if (!token) return null;
    if (provider === "spotify") return `Certifyd proof: ${token}`;
    if (provider === "tiktok") return `certifyd-proof account=${normalized} nonce=${token}`;
    if (provider === "youtube" || provider === "github") return `certifyd-proof provider=${provider} account=${normalized} nonce=${token}`;
    return null;
  }

  app.socialProofContract = { SPEC, compact, normalizeAccount, findCanonicalMarker, generatedMarker };
  if (typeof module !== "undefined" && module.exports) module.exports = app.socialProofContract;
})(globalThis);
