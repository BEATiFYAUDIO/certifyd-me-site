(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function parseNodeRootUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) return null;
      if (url.pathname !== "" && url.pathname !== "/") return null;
      return { nodeUrl: url.origin, profileUrl: null, proofsUrl: null };
    } catch {
      return null;
    }
  }

  function parseProfileUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) return null;
      const match = /^\/u\/([a-z0-9][a-z0-9_-]{0,63})\/?$/i.exec(url.pathname);
      if (!match) return null;
      const handle = match[1].toLowerCase();
      return {
        handle,
        nodeUrl: url.origin,
        profileUrl: `${url.origin}/u/${handle}`,
        proofsUrl: `${url.origin}/u/${handle}/proofs.json`
      };
    } catch {
      return null;
    }
  }

  // Pure comparison only. A future network layer must fetch the bundle safely.
  function comparePublicProof({ provider, account, profileUrl, bundle } = {}) {
    const profile = parseProfileUrl(profileUrl);
    if (!profile || typeof provider !== "string" || !provider.trim() ||
        typeof account !== "string" || !account.trim()) {
      return { status: "invalid_input", profile };
    }
    if (!bundle || typeof bundle !== "object" ||
        bundle.version !== 1 ||
        bundle.handle !== profile.handle ||
        bundle.profileUrl !== profile.profileUrl ||
        bundle.nodeUrl !== profile.nodeUrl ||
        bundle.witness?.algorithm !== "ed25519" ||
        typeof bundle.witness.publicKey !== "string" ||
        !bundle.witness.publicKey ||
        !Array.isArray(bundle.proofs?.social)) {
      return { status: "invalid_bundle", profile };
    }

    const externalIdentity = { provider: provider.trim().toLowerCase(), account: account.trim() };
    const match = bundle.proofs.social.find((proof) =>
      proof && proof.provider === externalIdentity.provider && proof.account === externalIdentity.account &&
      typeof proof.verifiedAt === "string" && Number.isFinite(Date.parse(proof.verifiedAt))
    );
    return {
      status: match ? "core_reports_verified" : "no_matching_proof",
      profile,
      externalIdentity,
      proof: match ? { provider: match.provider, account: match.account, verifiedAt: match.verifiedAt || null } : null
    };
  }

  app.certifyd = { parseNodeRootUrl, parseProfileUrl, comparePublicProof };
  if (typeof module !== "undefined" && module.exports) module.exports = app.certifyd;
})(globalThis);
