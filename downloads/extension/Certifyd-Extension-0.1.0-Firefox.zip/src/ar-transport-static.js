(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};
  const REGISTRY_FILE = "registry.json";

  function configuredRegistryBase() {
    return String(app.arConfig?.CERTIFYD_AR_REGISTRY_BASE || "").trim();
  }

  function configuredPublishEndpoint() {
    return String(app.arConfig?.CERTIFYD_AR_PUBLISH_ENDPOINT || "").trim();
  }

  function normalizeBaseUrl(value = configuredRegistryBase()) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" && url.protocol !== "http:") return null;
      if (url.protocol === "http:" && !/^localhost$|^127\.0\.0\.1$/.test(url.hostname)) return null;
      if (!url.pathname.endsWith("/")) url.pathname += "/";
      url.search = "";
      url.hash = "";
      return url.href;
    } catch {
      return null;
    }
  }

  function registryUrl(baseUrl = configuredRegistryBase()) {
    const base = normalizeBaseUrl(baseUrl);
    if (!base) throw new Error("Invalid Certifyd AR registry base URL.");
    return new URL(REGISTRY_FILE, base).href;
  }

  function parseJson(text, message) {
    try { return JSON.parse(text); } catch { throw new Error(message); }
  }

  function sendRuntimeMessage(message) {
    if (root.browser?.runtime?.sendMessage) {
      try {
        const result = root.browser.runtime.sendMessage(message);
        return result && typeof result.then === "function" ? result.catch(() => null) : Promise.resolve(result || null);
      } catch {
        return Promise.resolve(null);
      }
    }
    const runtime = root.chrome?.runtime;
    if (!runtime?.sendMessage) return Promise.resolve(null);
    return new Promise((resolve) => {
      let settled = false;
      function done(value) {
        if (settled) return;
        settled = true;
        resolve(value || null);
      }
      try {
        const maybePromise = runtime.sendMessage(message, (response) => {
          const lastError = root.chrome?.runtime?.lastError || runtime.lastError;
          done(lastError ? null : response);
        });
        if (maybePromise && typeof maybePromise.then === "function") {
          maybePromise.then(done, () => done(null));
        }
      } catch {
        done(null);
      }
    });
  }

  async function fetchTextViaRuntime(url) {
    try {
      const response = await sendRuntimeMessage({ type: "CERTIFYD_FETCH_PUBLIC_TEXT", url });
      return response?.ok && typeof response.text === "string" ? response.text : null;
    } catch {
      return null;
    }
  }

  async function fetchJson(url, { fetcher = root.fetch?.bind(root), signal, limit = 128000 } = {}) {
    let text = null;
    if (fetcher) {
      try {
        const response = await fetcher(url, { credentials: "omit", redirect: "error", cache: "no-store", signal });
        if (response.ok) text = await response.text();
      } catch {}
    }
    if (text === null) text = await fetchTextViaRuntime(url);
    if (typeof text !== "string") throw new Error("Certifyd AR registry fetch failed.");
    if (text.length > limit) throw new Error("Certifyd AR registry response is too large.");
    return parseJson(text, "Certifyd AR registry response is invalid JSON.");
  }

  function normalizePublishUrl(value = configuredPublishEndpoint()) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" && !(url.protocol === "http:" && /^localhost$|^127\.0\.0\.1$/.test(url.hostname))) return null;
      if (url.username || url.password || url.hash) return null;
      return url.href;
    } catch {
      return null;
    }
  }

  async function publishRecord({ page, envelope, publishUrl = configuredPublishEndpoint(), fetcher = root.fetch?.bind(root), crypto = root.crypto, signal } = {}) {
    const url = normalizePublishUrl(publishUrl);
    if (!url) throw new Error("Publishing is not connected yet.");
    if (!fetcher) throw new Error("Certifyd AR publishing is unavailable.");
    if (page?.status !== "verified" || !page.profileUrl || !page.externalIdentity || !envelope?.payload) {
      throw new Error("Save AR on a verified creator page before publishing.");
    }
    const signed = await app.arRecord?.verifySignedRecord?.(envelope, page, { crypto });
    if (!signed) throw new Error("Saved AR record does not match this page.");
    const authorized = await app.ar?.verifyConnection?.({
      bundle: page.bundle,
      profileUrl: page.profileUrl,
      publicKey: envelope.publicKey,
      crypto
    });
    if (!authorized) throw new Error("Not connected");
    const response = await fetcher(url, {
      method: "POST",
      credentials: "omit",
      redirect: "error",
      signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ record: envelope })
    });
    const text = await response.text();
    const payload = text ? parseJson(text, "Certifyd AR publish response is invalid JSON.") : {};
    if (!response.ok || payload?.ok === false) {
      throw new Error(payload?.message || payload?.error || "Publish failed");
    }
    return payload;
  }

  function lookup(registry, { profileUrl, provider, account } = {}) {
    if (registry?.version !== 1 || !registry.records || typeof registry.records !== "object") return null;
    const entry = registry.records?.[profileUrl]?.[provider]?.[account];
    const recordUrl = typeof entry === "string" ? entry : entry?.recordUrl;
    return typeof recordUrl === "string" && recordUrl.trim() ? recordUrl.trim() : null;
  }

  function registryProfileUrls(registry) {
    if (registry?.version !== 1 || !registry.records || typeof registry.records !== "object") return [];
    return Object.keys(registry.records).filter((profileUrl) => app.certifyd?.parseProfileUrl?.(profileUrl));
  }

  function lookupProfileReferences(registry, { provider, account } = {}) {
    const normalizedProvider = String(provider || "").trim().toLowerCase();
    const normalizedAccount = String(account || "").trim().toLowerCase();
    if (!normalizedProvider || !normalizedAccount) return [];
    const refs = [];
    for (const profileUrl of registryProfileUrls(registry)) {
      const providers = registry.records[profileUrl];
      const accounts = providers?.[normalizedProvider];
      if (!accounts || typeof accounts !== "object") continue;
      const matchKey = Object.keys(accounts).find((key) => String(key || "").trim().toLowerCase() === normalizedAccount);
      if (!matchKey) continue;
      const recordUrl = typeof accounts[matchKey] === "string" ? accounts[matchKey] : accounts[matchKey]?.recordUrl;
      if (typeof recordUrl === "string" && recordUrl.trim()) refs.push(profileUrl);
    }
    return refs;
  }

  async function findProfileReferencesForIdentity(identity, {
    baseUrl = configuredRegistryBase(),
    fetcher = root.fetch?.bind(root),
    signal
  } = {}) {
    let indexUrl;
    try { indexUrl = registryUrl(baseUrl); } catch { return []; }
    const registry = await fetchJson(indexUrl, { fetcher, signal }).catch(() => null);
    const exact = lookupProfileReferences(registry, identity);
    return exact.length ? exact : registryProfileUrls(registry);
  }

  function resolveRecordUrl(recordUrl, baseUrl = configuredRegistryBase()) {
    const base = normalizeBaseUrl(baseUrl);
    if (!base) return null;
    try {
      const url = new URL(recordUrl, base);
      if (url.protocol !== "https:" && !(url.protocol === "http:" && /^localhost$|^127\.0\.0\.1$/.test(url.hostname))) {
        return null;
      }
      if (url.username || url.password || url.hash) return null;
      return url.href;
    } catch {
      return null;
    }
  }

  function parseRecordFile(payload) {
    if (payload?.transport !== undefined) {
      if (payload.transport?.version !== 1 || payload.transport?.type !== "certifyd-static-registry") return null;
    }
    return payload?.record || null;
  }

  async function loadVerifiedPublicRecord(page, {
    baseUrl = configuredRegistryBase(),
    fetcher = root.fetch?.bind(root),
    crypto = root.crypto,
    signal
  } = {}) {
    if (page?.status !== "verified" || !page.profileUrl || !page.externalIdentity) return null;
    let indexUrl;
    try { indexUrl = registryUrl(baseUrl); } catch { return null; }
    const registry = await fetchJson(indexUrl, { fetcher, signal }).catch(() => null);
    const recordRef = lookup(registry, {
      profileUrl: page.profileUrl,
      provider: page.externalIdentity.provider,
      account: page.externalIdentity.account
    });
    if (!recordRef) return null;
    const recordUrl = resolveRecordUrl(recordRef, baseUrl);
    if (!recordUrl) return null;
    const recordFile = await fetchJson(recordUrl, { fetcher, signal, limit: 64000 }).catch(() => null);
    const envelope = parseRecordFile(recordFile);
    if (!envelope) return null;
    const signed = await app.arRecord?.verifySignedRecord?.(envelope, page, { crypto });
    if (!signed) return null;
    const authorized = await app.ar?.verifyConnection?.({
      bundle: page.bundle,
      profileUrl: page.profileUrl,
      publicKey: signed.publicKey,
      crypto
    });
    return authorized ? signed : null;
  }

  app.arTransportStatic = {
    REGISTRY_FILE,
    configuredRegistryBase,
    configuredPublishEndpoint,
    normalizeBaseUrl,
    registryUrl,
    sendRuntimeMessage,
    fetchTextViaRuntime,
    normalizePublishUrl,
    lookup,
    registryProfileUrls,
    lookupProfileReferences,
    findProfileReferencesForIdentity,
    resolveRecordUrl,
    parseRecordFile,
    publishRecord,
    loadVerifiedPublicRecord
  };
  if (typeof module !== "undefined" && module.exports) module.exports = app.arTransportStatic;
})(globalThis);
