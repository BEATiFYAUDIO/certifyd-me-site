(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  // Public Certifyd AR beta endpoints. They intentionally do not point at a creator Core node.
  const defaults = {
    CERTIFYD_AR_PUBLISH_ENDPOINT: "https://ar-publish.certifyd.me/publish",
    CERTIFYD_AR_REGISTRY_BASE: "https://beatifyaudio.github.io/certifyd-ar-registry/"
  };

  app.arConfig = {
    ...defaults,
    ...(app.arConfig || {})
  };

  if (typeof module !== "undefined" && module.exports) module.exports = app.arConfig;
})(globalThis);
