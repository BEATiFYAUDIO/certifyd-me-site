(function (root) {
  root.console?.info?.("[Certifyd AR][Content] startup", { href: root.location?.href });
  const app = root.CertifydExtension;
  const adapter = app?.adapters?.find(root.location?.href);
  if (!adapter) {
    root.console?.info?.("[Certifyd AR][Content] no-adapter", { href: root.location?.href, hasApp: Boolean(app), hasAdapters: Boolean(app?.adapters) });
    return;
  }
  root.console?.info?.("[Certifyd AR][Content] adapter-found", { href: root.location?.href });

  let generation = 0;
  let currentKey = null;
  let currentTarget = null;
  let removeUi = null;
  let controller = null;
  let candidate = null;
  let verifiedPage = null;

  function log(step, details = {}) {
    root.console?.debug?.("[Certifyd AR][Content]", step, details);
  }

  function clear() {
    generation += 1;
    controller?.abort();
    controller = null;
    removeUi?.();
    removeUi = null;
    currentKey = null;
    currentTarget = null;
    verifiedPage = null;
  }

  function describeMountedButton(mountTarget) {
    const button = mountTarget?.querySelector?.(".certifyd-ext__badge");
    const parent = button?.parentElement || null;
    const style = button && root.getComputedStyle ? root.getComputedStyle(button) : null;
    const rect = button?.getBoundingClientRect?.();
    return {
      exists: Boolean(button),
      isConnected: button?.isConnected === true,
      parentConnected: parent?.isConnected === true,
      display: style?.display || null,
      visibility: style?.visibility || null,
      opacity: style?.opacity || null,
      position: style?.position || null,
      zIndex: style?.zIndex || null,
      rect: rect ? { left: Math.round(rect.left), top: Math.round(rect.top), width: Math.round(rect.width), height: Math.round(rect.height) } : null
    };
  }

  async function verifyPage(nextCandidate) {
    if (!nextCandidate) {
      log("verify:no-candidate");
      if (currentKey !== null) clear();
      candidate = null;
      return { status: "unverified" };
    }
    const { externalIdentity, discovery, mountTarget } = nextCandidate;
    log("verify:candidate", { externalIdentity, discovery, hasMountTarget: Boolean(mountTarget) });
    const key = [externalIdentity.provider, externalIdentity.account,
      discovery.challenge, discovery.profileUrl].join("|");
    clear();
    candidate = nextCandidate;
    currentKey = key;
    currentTarget = mountTarget;
    const request = ++generation;
    const requestController = new AbortController();
    controller = requestController;
    const timeout = root.setTimeout(() => requestController.abort(), 8000);
    const resolveProfile = app.network.resolveProfileReference || ((value) => Promise.resolve(app.certifyd.parseProfileUrl(value)));
    const profile = await resolveProfile(discovery.profileUrl, root.fetch.bind(root), requestController.signal);
    if (!profile) {
      log("verify:profile-reference-failed", { profileUrl: discovery.profileUrl });
      root.clearTimeout(timeout);
      return { status: "unverified" };
    }
    log("verify:profile-reference", { input: discovery.profileUrl, profile });
    let response;
    try {
      log("verify:fetch-proofs", { proofsUrl: profile.proofsUrl });
      response = await app.network.fetchProofBundle(profile, root.fetch.bind(root), requestController.signal);
    } finally {
      root.clearTimeout(timeout);
    }
    if (request !== generation || (mountTarget && !mountTarget.isConnected)) {
      log("verify:stale-or-disconnected", { request, generation, mountConnected: mountTarget?.isConnected });
      return { status: "unverified" };
    }
    if (!response.ok) {
      log("verify:proof-fetch-failed", response);
      return { status: "unavailable" };
    }
    const result = app.certifyd.comparePublicProof({
      ...externalIdentity,
      profileUrl: profile.profileUrl,
      bundle: response.bundle
    });
    log("verify:core-result", {
      status: result.status,
      externalIdentity: result.externalIdentity,
      matchedProof: result.proof,
      coreProofs: response.bundle?.proofs?.social
        ?.filter((proof) => proof?.provider === externalIdentity.provider)
        ?.map((proof) => ({ provider: proof.provider, account: proof.account, verifiedAt: proof.verifiedAt }))
    });
    if (result.status !== "core_reports_verified") return { status: "unverified" };
    const profileAssets = await app.network.fetchProfileAssets?.(profile, root.fetch.bind(root), requestController.signal)
      .catch(() => ({}));
    verifiedPage = {
      status: "verified",
      externalIdentity: result.externalIdentity,
      profileUrl: profile.profileUrl,
      bundle: response.bundle,
      profileAssets
    };
    const arRecord = await app.arTransportStatic?.loadVerifiedPublicRecord?.(verifiedPage, {
      fetcher: root.fetch.bind(root)
    }).catch?.(() => null);
    const runtime = root.browser?.runtime || root.chrome?.runtime;
    if (mountTarget?.isConnected) {
      log("verify:mount-button", { provider: result.externalIdentity.provider, account: result.externalIdentity.account });
      removeUi = app.ui.mount(mountTarget, {
        name: response.bundle.displayName || "Certifyd profile",
        profileUrl: profile.profileUrl,
        arPayload: arRecord?.payload,
        profileAssets,
        iconUrl: runtime?.getURL?.("icons/certifyd-mark-32.png")
      });
      if (result.externalIdentity.provider === "tiktok") {
        log("button-inserted", describeMountedButton(mountTarget));
        root.setTimeout?.(() => log("button-after-render", describeMountedButton(mountTarget)), 500);
      }
    } else {
      log("verify:no-button-mount-target", { provider: result.externalIdentity.provider, account: result.externalIdentity.account });
    }
    return verifiedPage;
  }

  function onCandidate(nextCandidate) {
    if (!nextCandidate) return verifyPage(null);
    const { externalIdentity, discovery, mountTarget } = nextCandidate;
    log("verify:candidate", { externalIdentity, discovery, hasMountTarget: Boolean(mountTarget) });
    const key = [externalIdentity.provider, externalIdentity.account,
      discovery.challenge, discovery.profileUrl].join("|");
    if (key === currentKey && mountTarget === currentTarget) return Promise.resolve(verifiedPage);
    return verifyPage(nextCandidate);
  }

  const runtime = root.browser?.runtime || root.chrome?.runtime;
  runtime?.onMessage?.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "CERTIFYD_REFRESH_PAGE") return false;
    Promise.resolve(adapter.readCurrent
      ? adapter.readCurrent(root, root.document)
      : candidate)
      .then((fresh) => verifyPage(fresh))
      .then(sendResponse, () => sendResponse({ status: "unavailable" }));
    return true;
  });

  adapter.start({ window: root, document: root.document, onCandidate });
})(globalThis);
