(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function log(step, details = {}) {
    root.console?.debug?.("[Certifyd AR][TikTok]", step, details);
  }

  const RESERVED = new Set([
    "about", "business", "channel", "discover", "download", "explore", "foryou", "following",
    "friends", "inbox", "legal", "live", "login", "messages", "music", "search", "settings",
    "shop", "tag", "upload", "video"
  ]);

  function normalizeUsername(value) {
    const text = String(value || "").trim().replace(/^@/, "");
    if (!/^[A-Za-z0-9._]{2,24}$/.test(text)) return null;
    const lower = text.toLowerCase();
    return RESERVED.has(lower) ? null : lower;
  }

  function identityFromUrl(value) {
    let url;
    try { url = new URL(value); } catch { return null; }
    if (url.protocol !== "https:" || url.hostname !== "www.tiktok.com") return null;
    const match = /^\/@([A-Za-z0-9._]{2,24})\/?$/.exec(url.pathname);
    const account = normalizeUsername(match?.[1]);
    if (!account) return null;
    return { provider: "tiktok", account, source: "profile-url" };
  }

  function parseMarker(text) {
    const canonical = app.socialProofContract?.findCanonicalMarker?.("tiktok", text);
    if (canonical) return canonical;

    // Backward-compatible legacy extension marker without nonce.
    const source = app.socialProofContract?.compact?.(text) || String(text || "");
    const legacy = /(?:^|\s)certifyd-proof\s+provider=tiktok\s+account=([A-Za-z0-9._]{2,24})(?=\s|$)/i.exec(source);
    const account = normalizeUsername(legacy?.[1]);
    return account ? { provider: "tiktok", account, nonce: null, marker: `certifyd-proof provider=tiktok account=${account}`, format: "legacy-no-nonce" } : null;
  }

  function parseProfileReference(text) {
    if (typeof text !== "string") return null;
    const profileLabels = [...text.matchAll(/(?:^|\s)Certifyd profile:/gi)];
    if (profileLabels.length !== 1) return null;
    const profile = /(?:^|\s)Certifyd profile:\s*(https:\/\/\S+)/i.exec(text);
    if (!profile) return null;
    const parsed = app.certifyd?.parseProfileUrl(profile[1]) || app.certifyd?.parseNodeRootUrl?.(profile[1]);
    return parsed ? parsed.profileUrl || parsed.nodeUrl : null;
  }

  function parseDiscovery(text) {
    const proofMarkerCount = [...String(text || "").matchAll(/(?:^|\s)(?:certifyd-proof|Certifyd proof:)/gi)].length;
    if (proofMarkerCount !== 1) return null;
    const marker = parseMarker(text);
    if (marker?.profileUrl) return { challenge: marker.marker, profileUrl: marker.profileUrl, marker };
    const profileUrl = parseProfileReference(text);
    if (!profileUrl) return null;
    if (marker) return { challenge: marker.marker, profileUrl, marker };
    const modern = /(?:^|\s)Certifyd proof:\s*([0-9a-f]{32})(?=\s|$)/i.exec(String(text || ""));
    return modern ? { challenge: `Certifyd proof: ${modern[1].toLowerCase()}`, profileUrl } : null;
  }

  function decodeEntities(text) {
    const textarea = root.document?.createElement?.("textarea");
    if (textarea) {
      textarea.innerHTML = String(text || "");
      return textarea.value;
    }
    return String(text || "")
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&amp;/g, "&");
  }

  function collectJsonStrings(value, out = []) {
    if (typeof value === "string") {
      if (/certifyd|https:\/\//i.test(value)) out.push(value);
      return out;
    }
    if (Array.isArray(value)) {
      for (const item of value) collectJsonStrings(item, out);
      return out;
    }
    if (value && typeof value === "object") {
      for (const item of Object.values(value)) collectJsonStrings(item, out);
    }
    return out;
  }

  function jsonScriptTexts(doc) {
    const texts = [];
    for (const node of doc?.querySelectorAll?.('script[type="application/json"], script#__UNIVERSAL_DATA_FOR_REHYDRATION__, script#SIGI_STATE') || []) {
      const raw = node.textContent || "";
      if (!raw) continue;
      try {
        const parsed = JSON.parse(raw);
        texts.push(...collectJsonStrings(parsed));
      } catch {
        texts.push(raw);
      }
    }
    return texts;
  }

  function discoveryEntries(doc) {
    const scopes = [
      doc?.querySelector?.("main"),
      doc?.querySelector?.('[data-e2e="user-page"]'),
      doc?.querySelector?.('[data-e2e="user-bio"]'),
      doc?.body
    ].filter(Boolean);
    const metaSelectors = [
      'meta[name="description"]',
      'meta[property="og:description"]',
      'meta[name="twitter:description"]'
    ];
    const entries = [];
    const pageText = scopes.map((node) => node?.textContent || "").filter(Boolean).join("\n");
    if (pageText) entries.push({ source: "rendered-profile-text", text: pageText });
    for (const selector of metaSelectors) {
      const text = doc?.querySelector?.(selector)?.content || "";
      if (text) entries.push({ source: selector, text: decodeEntities(text) });
    }
    for (const text of jsonScriptTexts(doc)) entries.push({ source: "json-script", text });
    return entries;
  }

  function directMarker(doc) {
    for (const entry of discoveryEntries(doc)) {
      const marker = parseMarker(entry.text);
      if (marker) return marker;
    }
    return null;
  }

  function directDiscovery(doc) {
    for (const entry of discoveryEntries(doc)) {
      const discovery = parseDiscovery(entry.text);
      if (discovery) return discovery;
    }
    return null;
  }

  function profileLinks(doc) {
    const links = [];
    const selectors = [
      '[data-e2e="user-link"] a[href]',
      '[data-e2e="user-bio"] a[href]',
      'a[href]'
    ];
    for (const selector of selectors) {
      for (const node of doc?.querySelectorAll?.(selector) || []) {
        const href = node.href || node.getAttribute?.("href");
        if (href && !links.includes(href)) links.push(href);
      }
      if (links.length && selector !== 'a[href]') break;
    }
    return links;
  }

  function candidateProfileReferences(doc) {
    const refs = [];
    const push = (value) => {
      if (typeof value !== "string" || !value.trim()) return;
      if (!refs.includes(value)) refs.push(value);
    };
    for (const href of profileLinks(doc)) {
      try {
        const url = new URL(href, "https://www.tiktok.com/");
        if (url.protocol !== "https:") continue;
        const direct = app.certifyd?.parseProfileUrl(url.href) || app.certifyd?.parseNodeRootUrl?.(url.href);
        if (direct) push(direct.profileUrl || direct.nodeUrl);
        const host = url.hostname.toLowerCase().replace(/^www\./, "");
        const skipCertifydSubdomain = host.startsWith("certifyd.") || /(^|\.)(tiktok\.com|tiktokcdn\.com|tiktokv\.com|ttwstatic\.com|byteoversea\.com)$/.test(host);
        if (host && !skipCertifydSubdomain) push(`https://certifyd.${host}`);
      } catch {}
    }
    return refs;
  }

  function safeTikTokProfileUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== "www.tiktok.com" || url.username || url.password || url.search || url.hash) return null;
      const match = /^\/@([A-Za-z0-9._]{2,24})\/?$/.exec(url.pathname);
      const account = normalizeUsername(match?.[1]);
      if (!account) return null;
      url.pathname = `/@${account}/`;
      return { href: url.href, account };
    } catch {
      return null;
    }
  }

  function verifiedTikTokProof(bundle, account) {
    const proofs = Array.isArray(bundle?.proofs?.social) ? bundle.proofs.social : [];
    return proofs.find((proof) => proof?.provider === "tiktok" &&
      normalizeUsername(proof.account) === account &&
      typeof proof.verifiedAt === "string" && Number.isFinite(Date.parse(proof.verifiedAt)) &&
      safeTikTokProfileUrl(proof.location));
  }

  async function registryProfileReferences(externalIdentity, { fetcher = root.fetch?.bind(root), signal } = {}) {
    if (!externalIdentity || !app.arTransportStatic?.findProfileReferencesForIdentity) return [];
    const refs = await app.arTransportStatic.findProfileReferencesForIdentity(externalIdentity, { fetcher, signal }).catch(() => []);
    log("core-candidate", { source: "public-registry", account: externalIdentity.account, refs });
    return refs;
  }

  async function resolveViaCoreLinkedProfile(doc, externalIdentity, { fetcher = root.fetch?.bind(root), signal } = {}) {
    if (!externalIdentity || typeof fetcher !== "function") return null;
    const marker = directMarker(doc);
    if (marker && marker.account !== externalIdentity.account) {
      log("fallback:marker-account-mismatch", { markerAccount: marker.account, account: externalIdentity.account });
      return null;
    }
    const linkRefs = candidateProfileReferences(doc);
    log("core-candidate", { source: "profile-links", account: externalIdentity.account, refs: linkRefs });
    const registryRefs = marker ? await registryProfileReferences(externalIdentity, { fetcher, signal }) : [];
    const refs = [...new Set([...linkRefs, ...registryRefs])];
    log("fallback:refs", { account: externalIdentity.account, refs });
    for (const ref of refs) {
      const profile = await app.network?.resolveProfileReference?.(ref, fetcher, signal);
      if (!profile) { log("fallback:no-profile", { ref }); continue; }
      log("core-candidate", { source: "resolved-profile", ref, profileUrl: profile.profileUrl, nodeUrl: profile.nodeUrl });
      const response = await app.network?.fetchProofBundle?.(profile, fetcher, signal);
      log("core-proof", { profileUrl: profile.profileUrl, ok: Boolean(response?.ok), reason: response?.reason || null });
      if (!response?.ok) { log("fallback:proof-fetch-failed", { ref, reason: response?.reason }); continue; }
      const result = app.certifyd?.comparePublicProof?.({
        provider: "tiktok",
        account: externalIdentity.account,
        profileUrl: profile.profileUrl,
        bundle: response.bundle
      });
      log("verified", { profileUrl: profile.profileUrl, status: result?.status || null });
      if (result?.status !== "core_reports_verified") { log("fallback:core-mismatch", { ref, status: result?.status }); continue; }
      const proof = verifiedTikTokProof(response.bundle, externalIdentity.account);
      const location = safeTikTokProfileUrl(proof?.location);
      if (!location || location.account !== externalIdentity.account) { log("fallback:location-mismatch", { location: proof?.location }); continue; }
      log("fallback:matched", { profileUrl: profile.profileUrl, marker: marker?.marker || null });
      return {
        discovery: {
          challenge: marker?.marker || `core-verified:tiktok:${externalIdentity.account}`,
          profileUrl: profile.profileUrl,
          marker: marker || null
        },
        source: marker ? "marker-plus-core-linked-tiktok-profile" : "core-linked-tiktok-profile"
      };
    }
    return null;
  }

  function describeElement(node) {
    if (!node) return null;
    return {
      tag: node.tagName || node.nodeName || null,
      id: node.id || "",
      className: typeof node.className === "string" ? node.className : String(node.className || ""),
      dataE2e: node.getAttribute?.("data-e2e") || "",
      ariaLabel: node.getAttribute?.("aria-label") || "",
      role: node.getAttribute?.("role") || "",
      connected: node.isConnected !== false
    };
  }

  function makeMountHost(doc, anchor, source) {
    if (!doc?.createElement || !anchor || anchor.isConnected === false) return null;
    const existing = doc.querySelector?.('[data-certifyd-tiktok-mount="true"]');
    if (existing && existing.isConnected !== false) return { node: existing, source: `${source}::existing-certifyd-host`, detail: describeElement(existing) };

    const host = doc.createElement("span");
    host.className = "certifyd-tiktok-mount";
    host.setAttribute?.("data-certifyd-tiktok-mount", "true");
    host.setAttribute?.("aria-hidden", "false");
    if (host.style) {
      host.style.display = "inline-flex";
      host.style.alignItems = "center";
      host.style.verticalAlign = "middle";
    }

    if (typeof anchor.insertAdjacentElement === "function") anchor.insertAdjacentElement("afterend", host);
    else if (typeof anchor.after === "function") anchor.after(host);
    else if (anchor.parentNode?.insertBefore) anchor.parentNode.insertBefore(host, anchor.nextSibling || null);
    else if (anchor.parentElement?.append) anchor.parentElement.append(host);
    else if (anchor.append) anchor.append(host);

    return host.isConnected === false ? null : { node: host, source: `${source}::certifyd-host`, detail: describeElement(host) };
  }

  function findMountTarget(doc) {
    const existing = doc?.querySelector?.('[data-certifyd-tiktok-mount="true"]');
    if (existing && existing.isConnected !== false) return { node: existing, source: "existing-certifyd-host", detail: describeElement(existing) };

    for (const selector of [
      '[data-e2e="user-title"]',
      '[data-e2e="user-info"] h1',
      'h1[data-e2e]',
      'main h1'
    ]) {
      const node = doc?.querySelector?.(selector);
      if (node && node.isConnected !== false) {
        const host = makeMountHost(doc, node, selector);
        if (host) return host;
      }
    }

    for (const selector of [
      '[data-e2e="user-info"]',
      '[data-e2e="user-page"] [data-e2e="user-info"]',
      'main [data-e2e="user-info"]',
      '[data-e2e="user-subtitle"]'
    ]) {
      const node = doc?.querySelector?.(selector);
      if (node && node.isConnected !== false) {
        const host = makeMountHost(doc, node, selector);
        if (host) return host;
        return { node, source: selector, detail: describeElement(node) };
      }
    }
    return null;
  }

  function candidateFromDiscovery(externalIdentity, discovery, doc) {
    if (!externalIdentity || !discovery) return null;
    if (discovery.marker?.account && discovery.marker.account !== externalIdentity.account) return null;
    const mount = findMountTarget(doc);
    log("mount-target", { source: mount?.source || null, detail: mount?.detail || null });
    return {
      externalIdentity: { provider: "tiktok", account: externalIdentity.account },
      discovery,
      mountTarget: mount?.node || null,
      mountSource: mount?.source || null
    };
  }

  function readProfile(doc, url) {
    log("adapter:inspect", { url });
    const externalIdentity = identityFromUrl(url);
    if (!externalIdentity) {
      log("identity", { matched: false });
      return null;
    }
    log("identity", { provider: "tiktok", account: externalIdentity.account, source: externalIdentity.source });
    const discovery = directDiscovery(doc);
    log("marker", { found: Boolean(discovery), challenge: discovery?.challenge || null });
    log("profile-reference", { profileUrl: discovery?.profileUrl || null });
    return candidateFromDiscovery(externalIdentity, discovery, doc);
  }

  async function readProfileAsync(doc, url, options = {}) {
    log("adapter:inspect", { url });
    const externalIdentity = identityFromUrl(url);
    if (!externalIdentity) {
      log("identity", { matched: false });
      return null;
    }
    log("identity", { provider: "tiktok", account: externalIdentity.account, source: externalIdentity.source });
    const direct = directDiscovery(doc);
    if (direct) {
      const candidate = candidateFromDiscovery(externalIdentity, direct, doc);
      log("marker", { found: true, challenge: direct.challenge });
      log("profile-reference", { profileUrl: direct.profileUrl });
      log("readProfile:direct", { account: externalIdentity.account, hasMountTarget: Boolean(candidate?.mountTarget), mountSource: candidate?.mountSource || null });
      return candidate;
    }
    const marker = directMarker(doc);
    log("marker", { found: Boolean(marker), challenge: marker?.marker || null, format: marker?.format || null });
    const resolved = await resolveViaCoreLinkedProfile(doc, externalIdentity, options);
    log("profile-reference", { profileUrl: resolved?.discovery?.profileUrl || null, source: resolved?.source || null });
    const candidate = candidateFromDiscovery(externalIdentity, resolved?.discovery, doc);
    log("readProfile:fallback", { account: externalIdentity.account, matched: Boolean(resolved), hasMountTarget: Boolean(candidate?.mountTarget), mountSource: candidate?.mountSource || null });
    return candidate;
  }

  function start({ window: win, document: doc, onCandidate }) {
    root.console?.info?.("[Certifyd AR][TikTok] adapter-start", { href: win.location?.href });
    let timer = null;
    let lastUrl = win.location.href;
    let lastKey = null;
    let lastTarget = null;
    let sequence = 0;

    async function inspect() {
      timer = null;
      const request = ++sequence;
      const controller = win.AbortController ? new win.AbortController() : null;
      const candidate = await readProfileAsync(doc, win.location.href, {
        fetcher: win.fetch?.bind(win),
        signal: controller?.signal
      }).catch(() => null);
      if (request !== sequence) return;
      const key = candidate
        ? [candidate.externalIdentity.account, candidate.discovery.challenge, candidate.discovery.profileUrl].join("|")
        : null;
      if (key === lastKey && candidate?.mountTarget === lastTarget) return;
      lastKey = key;
      lastTarget = candidate?.mountTarget || null;
      onCandidate(candidate);
    }

    function schedule() {
      if (timer !== null) return;
      timer = win.setTimeout(inspect, 180);
    }

    const observer = new win.MutationObserver(schedule);
    observer.observe(doc.documentElement, { childList: true, characterData: true, subtree: true });
    const interval = win.setInterval(() => {
      if (lastUrl === win.location.href) return;
      lastUrl = win.location.href;
      schedule();
    }, 700);
    win.addEventListener("popstate", schedule);
    win.addEventListener("hashchange", schedule);
    inspect();

    return () => {
      observer.disconnect();
      win.clearInterval(interval);
      if (timer !== null) win.clearTimeout(timer);
      win.removeEventListener("popstate", schedule);
      win.removeEventListener("hashchange", schedule);
    };
  }

  const adapter = {
    matches: (value) => {
      try {
        const url = new URL(value);
        return url.protocol === "https:" && url.hostname === "www.tiktok.com";
      } catch {
        return false;
      }
    },
    start,
    readCurrent: (win, doc) => readProfileAsync(doc, win.location.href, { fetcher: win.fetch?.bind(win) })
  };

  app.tiktok = {
    normalizeUsername, identityFromUrl, parseMarker, parseProfileReference, parseDiscovery, discoveryEntries, directMarker, directDiscovery,
    profileLinks, candidateProfileReferences, safeTikTokProfileUrl, verifiedTikTokProof, collectJsonStrings, registryProfileReferences,
    resolveViaCoreLinkedProfile, findMountTarget, makeMountHost, describeElement, readProfile, readProfileAsync
  };
  app.adapters.register(adapter);
  if (typeof module !== "undefined" && module.exports) module.exports = app.tiktok;
})(globalThis);
