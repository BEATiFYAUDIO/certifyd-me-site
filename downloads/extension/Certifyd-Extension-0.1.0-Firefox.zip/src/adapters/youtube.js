(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function log(step, details = {}) {
    root.console?.debug?.("[Certifyd AR][YouTube]", step, details);
  }

  function normalizeHandle(value) {
    const text = String(value || "").trim().replace(/^@/, "");
    if (!/^[A-Za-z0-9._-]{3,30}$/.test(text)) return null;
    return text.toLowerCase();
  }

  function identityFromUrl(value, doc) {
    let url;
    try { url = new URL(value); } catch { return null; }
    if (url.protocol !== "https:" || url.hostname !== "www.youtube.com") return null;
    const handle = /^\/@([A-Za-z0-9._-]{3,30})(?:\/(?:featured|videos|shorts|streams|community|about|playlists|channels))?\/?$/.exec(url.pathname);
    if (handle) return { provider: "youtube", account: normalizeHandle(handle[1]), source: "handle" };

    const channel = /^\/channel\/([A-Za-z0-9_-]{10,})(?:\/(?:featured|videos|shorts|streams|community|about|playlists|channels))?\/?$/.exec(url.pathname);
    if (!channel) return null;
    const canonical = findCanonicalHandle(doc);
    if (canonical) return { provider: "youtube", account: canonical, source: "canonical-handle" };
    return { provider: "youtube", account: channel[1], source: "channel-id" };
  }

  function findCanonicalHandle(doc) {
    const candidates = [];
    for (const selector of [
      'link[rel="canonical"]',
      'meta[property="og:url"]',
      'meta[name="twitter:url"]'
    ]) {
      const node = doc?.querySelector?.(selector);
      const value = node?.href || node?.content || node?.getAttribute?.("href") || node?.getAttribute?.("content");
      if (value) candidates.push(value);
    }
    for (const value of candidates) {
      try {
        const url = new URL(value);
        if (url.hostname !== "www.youtube.com") continue;
        const match = /^\/@([A-Za-z0-9._-]{3,30})(?:\/)?$/.exec(url.pathname);
        const handle = normalizeHandle(match?.[1]);
        if (handle) return handle;
      } catch {}
    }
    return null;
  }

  function parseDiscovery(text) {
    if (typeof text !== "string") return null;
    const canonical = app.socialProofContract?.parseCanonicalEnvelope?.("youtube", text);
    if (canonical) return { challenge: canonical.marker, profileUrl: canonical.profileUrl, marker: canonical };

    const profileLabels = [...text.matchAll(/(?:^|\s)Certifyd profile:/gi)];
    if (profileLabels.length !== 1) return null;
    const profile = /(?:^|\s)Certifyd profile:\s*(https:\/\/\S+)/i.exec(text);
    if (!profile) return null;
    const parsed = app.certifyd?.parseProfileUrl(profile[1]) || app.certifyd?.parseNodeRootUrl?.(profile[1]);
    if (!parsed) return null;

    const modernProofs = [...text.matchAll(/(?:^|\s)Certifyd proof:/gi)];
    const legacyProofs = [...text.matchAll(/(?:^|\s)certifyd-proof\s+provider=youtube\s+account=([A-Za-z0-9._-]{3,30})\s+nonce=([A-Za-z0-9._-]+)/gi)];
    if (modernProofs.length + legacyProofs.length !== 1) return null;

    const modern = /(?:^|\s)Certifyd proof:\s*([0-9a-f]{32})(?=\s|$)/i.exec(text);
    if (modern) return { challenge: `Certifyd proof: ${modern[1].toLowerCase()}`, profileUrl: parsed.profileUrl || parsed.nodeUrl };
    const legacy = legacyProofs[0];
    if (legacy) return {
      challenge: `certifyd-proof provider=youtube account=${normalizeHandle(legacy[1])} nonce=${legacy[2]}`,
      profileUrl: parsed.profileUrl || parsed.nodeUrl
    };
    return null;
  }

  function discoveryEntries(doc) {
    const scopes = [
      doc?.querySelector?.("ytd-browse[page-subtype='channels']"),
      doc?.querySelector?.("ytd-browse"),
      doc?.querySelector?.("main"),
      doc?.body
    ].filter(Boolean);
    const metaSelectors = [
      'meta[name="description"]',
      'meta[property="og:description"]',
      'meta[name="twitter:description"]',
      'meta[itemprop="description"]'
    ];
    const entries = [];
    const pageText = scopes[0]?.textContent || "";
    if (pageText) entries.push({ source: "rendered-page-text", text: pageText });
    for (const selector of metaSelectors) {
      const text = doc?.querySelector?.(selector)?.content || "";
      if (text) entries.push({ source: selector, text });
    }
    return entries;
  }

  function discoveryTexts(doc) {
    return discoveryEntries(doc).map((entry) => entry.text);
  }

  function visibleText(doc) {
    return discoveryTexts(doc).join("\n");
  }

  function findMountTarget(doc) {
    for (const selector of [
      "#page-header h1",
      "#page-header [role='heading']",
      "#page-header yt-dynamic-text-view-model h1",
      "#page-header yt-dynamic-text-view-model",
      "#page-header yt-content-metadata-view-model h1",
      "yt-page-header-view-model h1",
      "yt-page-header-view-model [role='heading']",
      "yt-page-header-view-model yt-dynamic-text-view-model",
      "yt-page-header-renderer h1",
      "yt-page-header-renderer [role='heading']",
      "ytd-page-header-renderer h1",
      "ytd-page-header-renderer [role='heading']",
      "ytd-channel-name #text",
      "ytd-channel-name",
      "#channel-header-container ytd-channel-name",
      "yt-page-header-view-model",
      "yt-page-header-renderer",
      "ytd-page-header-renderer #page-header",
      "ytd-c4-tabbed-header-renderer #channel-header-container",
      "#channel-header-container",
      "#page-header",
      "#page-header-container",
      "ytd-browse[page-subtype='channels']"
    ]) {
      const node = doc?.querySelector?.(selector);
      if (node && node.isConnected !== false) return { node, source: selector };
    }
    return null;
  }

  function readProfile(doc, url) {
    log("readProfile:start", { url });
    const externalIdentity = identityFromUrl(url, doc);
    if (!externalIdentity) {
      log("readProfile:no-channel-identity", { url });
      return null;
    }
    log("identity", { provider: "youtube", account: externalIdentity.account, source: externalIdentity.source });
    const mount = findMountTarget(doc);
    if (!mount?.node) log("readProfile:no-mount-target", {});
    else log("mount-target", { source: mount.source });
    let discovery = null;
    let selectedSource = null;
    for (const entry of discoveryEntries(doc)) {
      discovery = parseDiscovery(entry.text);
      if (discovery) {
        selectedSource = entry.source;
        break;
      }
    }
    if (!discovery) {
      discovery = parseDiscovery(visibleText(doc));
      if (discovery) selectedSource = "combined-text";
    }
    if (!discovery) {
      log("readProfile:no-certifyd-discovery", { sources: discoveryEntries(doc).map((entry) => entry.source) });
      return null;
    }
    log("discovery", {
      source: selectedSource,
      challenge: discovery.challenge,
      profileUrl: discovery.profileUrl
    });
    if (discovery.marker?.account && discovery.marker.account !== externalIdentity.account) {
      log("discovery:account-mismatch", { markerAccount: discovery.marker.account, account: externalIdentity.account });
      return null;
    }
    return {
      externalIdentity: { provider: "youtube", account: externalIdentity.account },
      discovery,
      mountTarget: mount?.node || null
    };
  }

  function start({ window: win, document: doc, onCandidate }) {
    let timer = null;
    let lastUrl = win.location.href;
    let lastKey = null;
    let lastTarget = null;

    function inspect() {
      timer = null;
      log("adapter:inspect", { url: win.location.href });
      const candidate = readProfile(doc, win.location.href);
      const key = candidate
        ? [candidate.externalIdentity.account, candidate.discovery.challenge, candidate.discovery.profileUrl].join("|")
        : null;
      if (key === lastKey && candidate?.mountTarget === lastTarget) return;
      lastKey = key;
      lastTarget = candidate?.mountTarget || null;
      onCandidate(candidate);
    }

    function schedule() {
      if (timer !== null) return;
      timer = win.setTimeout(inspect, 180);
    }

    const observer = new win.MutationObserver(schedule);
    observer.observe(doc.documentElement, { childList: true, characterData: true, subtree: true });
    const interval = win.setInterval(() => {
      if (lastUrl === win.location.href) return;
      lastUrl = win.location.href;
      schedule();
    }, 700);
    win.addEventListener("popstate", schedule);
    win.addEventListener("hashchange", schedule);
    win.addEventListener("yt-navigate-finish", schedule);
    inspect();

    return () => {
      observer.disconnect();
      win.clearInterval(interval);
      if (timer !== null) win.clearTimeout(timer);
      win.removeEventListener("popstate", schedule);
      win.removeEventListener("hashchange", schedule);
      win.removeEventListener("yt-navigate-finish", schedule);
    };
  }

  const adapter = {
    matches: (value) => {
      try {
        const url = new URL(value);
        return url.protocol === "https:" && url.hostname === "www.youtube.com";
      } catch {
        return false;
      }
    },
    start,
    readCurrent: (win, doc) => readProfile(doc, win.location.href)
  };

  app.youtube = { normalizeHandle, identityFromUrl, parseDiscovery, readProfile, findCanonicalHandle, visibleText, findMountTarget };
  app.adapters.register(adapter);
  if (typeof module !== "undefined" && module.exports) module.exports = app.youtube;
})(globalThis);
