(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};
  const adapters = [];

  function register(adapter) {
    if (!adapter || typeof adapter.matches !== "function" || typeof adapter.start !== "function") {
      throw new TypeError("An adapter needs matches(url) and start(context)");
    }
    adapters.push(adapter);
  }

  function find(url) {
    return adapters.find((adapter) => adapter.matches(url)) || null;
  }

  app.adapters = { register, find };
  if (typeof module !== "undefined" && module.exports) module.exports = app.adapters;
})(globalThis);
