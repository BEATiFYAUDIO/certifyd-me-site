(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function decodeCanonical(value, bytes, pattern) {
    if (typeof value !== "string" || !pattern.test(value)) return null;
    try {
      const binary = root.atob(value);
      if (binary.length !== bytes || root.btoa(binary) !== value) return null;
      return Uint8Array.from(binary, (char) => char.charCodeAt(0));
    } catch {
      return null;
    }
  }

  const decodePublicKey = (value) => decodeCanonical(value, 32, /^[A-Za-z0-9+/]{43}=$/);
  const decodeSignature = (value) => decodeCanonical(value, 64, /^[A-Za-z0-9+/]{86}==$/);

  function authorizationFields(text) {
    if (typeof text !== "string") return null;
    const match = /^Certifyd AR authorization v1\nCreator: ([^\n\r]+)\nCreator key: ([A-Za-z0-9+/]{43}=)\nAR key: ([A-Za-z0-9+/]{43}=)\nPurpose: Certifyd AR publishing\nChallenge: ([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/.exec(text);
    if (!match) return null;
    const [, creatorId, creatorKey, arKey, challenge] = match;
    if (!decodePublicKey(creatorKey) || !decodePublicKey(arKey)) return null;
    return { creatorId, creatorKey, arKey, challenge };
  }

  async function verifyConnection({ bundle, profileUrl, publicKey, crypto = root.crypto } = {}) {
    const profile = app.certifyd?.parseProfileUrl(profileUrl);
    if (!profile || bundle?.version !== 1 || bundle.handle !== profile.handle ||
        bundle.profileUrl !== profile.profileUrl || bundle.nodeUrl !== profile.nodeUrl ||
        bundle.witness?.algorithm !== "ed25519" || !decodePublicKey(bundle.witness.publicKey) ||
        !decodePublicKey(publicKey) || !Array.isArray(bundle.connectedApps?.certifydAr)) return false;
    const matches = bundle.connectedApps.certifydAr.filter((entry) => entry?.publicKey === publicKey);
    if (matches.length !== 1) return false;
    const [entry] = matches;
    const fields = authorizationFields(entry.authorizationText);
    const signature = decodeSignature(entry.signature);
    if (!fields || !signature || fields.creatorKey !== bundle.witness.publicKey ||
        fields.arKey !== publicKey ||
        typeof entry.connectedAt !== "string" ||
        !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(entry.connectedAt) ||
        !Number.isFinite(Date.parse(entry.connectedAt)) ||
        !crypto?.subtle) return false;
    try {
      const key = await crypto.subtle.importKey("raw", decodePublicKey(bundle.witness.publicKey),
        { name: "Ed25519" }, false, ["verify"]);
      return await crypto.subtle.verify("Ed25519", key, signature,
        new TextEncoder().encode(entry.authorizationText));
    } catch {
      return false;
    }
  }

  function modeForPage({ page, key, connected } = {}) {
    return page?.status === "verified" && key?.publicKey && connected === true
      ? "creator" : "fan";
  }

  function supportsArConnections(bundle) {
    return Array.isArray(bundle?.connectedApps?.certifydAr);
  }

  app.ar = { decodePublicKey, decodeSignature, authorizationFields, verifyConnection, modeForPage, supportsArConnections };
  if (typeof module !== "undefined" && module.exports) module.exports = app.ar;
})(globalThis);
