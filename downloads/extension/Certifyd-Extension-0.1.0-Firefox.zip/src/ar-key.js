(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};
  const DB_NAME = "certifyd-ar";
  const STORE = "local-key";
  const ID = "device";

  function openDatabase(indexedDB = root.indexedDB) {
    if (!indexedDB) return Promise.reject(new Error("Browser key storage is unavailable."));
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: "id" });
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  function read(db) {
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, "readonly").objectStore(STORE).get(ID);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  function write(db, value) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(value);
      tx.oncomplete = () => resolve(value);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  function remove(db) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(ID);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  async function getKey(indexedDB = root.indexedDB) {
    const db = await openDatabase(indexedDB);
    try { return await read(db); } finally { db.close(); }
  }

  async function createKey(pairedProfileUrl, { indexedDB = root.indexedDB, crypto = root.crypto } = {}) {
    if (!app.certifyd?.parseProfileUrl(pairedProfileUrl)) throw new Error("Open a verified Certifyd profile first.");
    if (!crypto?.subtle) throw new Error("Ed25519 key generation is unavailable.");
    const db = await openDatabase(indexedDB);
    try {
      const existing = await read(db);
      if (existing) {
        await app.arRecord?.mirrorCurrentPublicKey?.(existing.publicKey)?.catch?.(() => {});
        return existing;
      }
      const pair = await crypto.subtle.generateKey({ name: "Ed25519" }, false, ["sign", "verify"]);
      const bytes = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
      const publicKey = root.btoa(String.fromCharCode(...bytes));
      const record = { id: ID, publicKey, privateKey: pair.privateKey, pairedProfileUrl };
      const saved = await write(db, record);
      await app.arRecord?.mirrorCurrentPublicKey?.(saved.publicKey)?.catch?.(() => {});
      return saved;
    } finally { db.close(); }
  }

  async function resetKey(pairedProfileUrl, { indexedDB = root.indexedDB, crypto = root.crypto } = {}) {
    if (!app.certifyd?.parseProfileUrl(pairedProfileUrl)) throw new Error("Open a verified Certifyd profile first.");
    const db = await openDatabase(indexedDB);
    try { await remove(db); } finally { db.close(); }
    return createKey(pairedProfileUrl, { indexedDB, crypto });
  }

  app.arKey = { getKey, createKey, resetKey };
  if (typeof module !== "undefined" && module.exports) module.exports = app.arKey;
})(globalThis);
