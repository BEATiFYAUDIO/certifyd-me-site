(function (root) {
  const runtime = root.browser?.runtime || root.chrome?.runtime;
  if (!runtime?.onMessage) return;

  function isAllowedPublicTextUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password) return false;
      if (url.hostname === "gist.github.com") return true;
      if (url.hostname === "beatifyaudio.github.io" && url.pathname.startsWith("/certifyd-ar-registry/")) return true;
      return false;
    } catch {
      return false;
    }
  }

  async function fetchPublicText(url) {
    if (!isAllowedPublicTextUrl(url)) return { ok: false, reason: "url_not_allowed" };
    const response = await fetch(url, {
      method: "GET",
      credentials: "omit",
      redirect: "error",
      cache: "no-store",
      headers: { accept: "text/html, application/json" }
    });
    const finalUrl = response.url || url;
    if (new URL(finalUrl).origin !== new URL(url).origin) return { ok: false, reason: "redirected" };
    const length = Number(response.headers?.get?.("content-length") || 0);
    if (length > 512000) return { ok: false, reason: "too_large" };
    const text = await response.text();
    if (text.length > 512000) return { ok: false, reason: "too_large" };
    return { ok: response.ok, status: response.status, url: finalUrl, text };
  }

  runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "CERTIFYD_FETCH_PUBLIC_TEXT") return false;
    fetchPublicText(message.url)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, reason: "fetch_failed", message: String(error?.message || error) }));
    return true;
  });
})(globalThis);
