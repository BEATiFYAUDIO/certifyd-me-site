(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};
  const DOMAIN = "Certifyd AR Record v1";
  const RECORD_PREFIX = "ar-record:";
  const CURRENT_KEY_ID = "ar-current-public-key";
  const textEncoder = new TextEncoder();
  const textDecoder = new TextDecoder();

  function storageArea(storage = root.browser?.storage?.local || root.chrome?.storage?.local) {
    if (!storage) throw new Error("Extension record storage is unavailable.");
    return storage;
  }

  function storageGet(keys, storage) {
    const area = storageArea(storage);
    if (root.browser?.storage?.local && area.get.length < 2) return area.get(keys);
    return new Promise((resolve, reject) => {
      area.get(keys, (result) => {
        const error = root.chrome?.runtime?.lastError;
        if (error) reject(error);
        else resolve(result || {});
      });
    });
  }

  function storageSet(value, storage) {
    const area = storageArea(storage);
    if (root.browser?.storage?.local && area.set.length < 2) return area.set(value);
    return new Promise((resolve, reject) => {
      area.set(value, () => {
        const error = root.chrome?.runtime?.lastError;
        if (error) reject(error);
        else resolve();
      });
    });
  }

  function keyFor({ profileUrl, provider, account } = {}) {
    if (!app.certifyd?.parseProfileUrl(profileUrl) || typeof provider !== "string" ||
        typeof account !== "string" || !provider || !account) {
      throw new Error("A verified creator context is required.");
    }
    return `${RECORD_PREFIX}${profileUrl}|${provider}|${account}`;
  }

  function canonicalize(value) {
    if (value === null) return "null";
    if (typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new Error("Invalid number in AR record.");
      return JSON.stringify(value);
    }
    if (typeof value === "boolean") return value ? "true" : "false";
    if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
    if (typeof value === "object") {
      return `{${Object.keys(value).sort().map((key) =>
        `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(",")}}`;
    }
    throw new Error("Invalid value in AR record.");
  }

  function signingText(payload) {
    return `${DOMAIN}\n${canonicalize(payload)}`;
  }

  function base64(bytes) {
    return root.btoa(String.fromCharCode(...new Uint8Array(bytes)));
  }

  function bytesFromBase64(value) {
    const decoded = app.ar?.decodeSignature(value) || app.ar?.decodePublicKey(value);
    if (decoded) return decoded;
    return null;
  }

  function normalizeHttpsUrl(value, optional = true) {
    const trimmed = String(value || "").trim();
    if (!trimmed) {
      if (optional) return "";
      throw new Error("Enter a valid HTTPS URL.");
    }
    let parsed;
    try { parsed = new URL(trimmed); } catch { throw new Error("Enter a valid HTTPS URL."); }
    if (parsed.protocol !== "https:" || parsed.username || parsed.password) {
      throw new Error("Only HTTPS URLs are allowed.");
    }
    return parsed.href;
  }

  function isLightningAddress(value) {
    return /^[^\s@]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(value);
  }

  function isBtcAddress(value) {
    return /^(bc1[ac-hj-np-z02-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(value);
  }

  function normalizeSupportDestination(value) {
    const trimmed = String(value || "").trim();
    if (!trimmed) throw new Error("Enter a support destination.");
    if (isLightningAddress(trimmed) || isBtcAddress(trimmed)) return trimmed;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "https:" && !parsed.username && !parsed.password) return parsed.href;
      if (parsed.protocol === "bitcoin:" || parsed.protocol === "lightning:") return trimmed;
    } catch {}
    throw new Error("Enter a valid Lightning address, BTC address, or HTTPS support URL.");
  }

  function cleanText(value, max, name) {
    const text = String(value || "").trim();
    if (text.length > max) throw new Error(`${name} is too long.`);
    return text;
  }

  function normalizeSlot(input = {}) {
    const revealTitle = cleanText(input.revealTitle, 80, "Reveal title");
    const revealText = cleanText(input.revealText, 500, "Reveal text");
    const revealUrl = normalizeHttpsUrl(input.revealUrl, true);
    const supportLabel = cleanText(input.supportLabel, 80, "Support label");
    const supportDestination = String(input.supportDestination || "").trim();
    const actionLabel = cleanText(input.actionLabel, 80, "Action label");
    const actionUrl = String(input.actionUrl || "").trim();
    const slots = {};

    if (revealTitle || revealText || revealUrl) {
      if (!revealText && !revealUrl) throw new Error("Reveal needs text or a link.");
      slots.reveal = {};
      if (revealTitle) slots.reveal.title = revealTitle;
      if (revealText) slots.reveal.text = revealText;
      if (revealUrl) slots.reveal.url = revealUrl;
    }
    if (supportLabel || supportDestination) {
      if (!supportLabel || !supportDestination) throw new Error("Support needs a label and destination.");
      slots.support = { label: supportLabel, destination: normalizeSupportDestination(supportDestination) };
    }
    if (actionLabel || actionUrl) {
      if (!actionLabel || !actionUrl) throw new Error("Action needs a label and destination.");
      slots.action = { label: actionLabel, url: normalizeHttpsUrl(actionUrl, false) };
    }
    return slots;
  }

  function buildPayload({ profileUrl, bundle, externalIdentity, input, sequence = 1, now = new Date() } = {}) {
    const profile = app.certifyd?.parseProfileUrl(profileUrl);
    if (!profile || !bundle || !externalIdentity?.provider || !externalIdentity?.account) {
      throw new Error("A verified creator context is required.");
    }
    return {
      version: 1,
      creator: {
        profileUrl: profile.profileUrl,
        nodeUrl: profile.nodeUrl,
        handle: profile.handle
      },
      context: {
        provider: String(externalIdentity.provider),
        account: String(externalIdentity.account)
      },
      slots: normalizeSlot(input),
      sequence,
      updatedAt: now.toISOString()
    };
  }

  async function signPayload(payload, key, crypto = root.crypto) {
    if (!key?.privateKey || !app.ar?.decodePublicKey(key.publicKey) || !crypto?.subtle) {
      throw new Error("This browser does not have an AR signing key.");
    }
    const text = signingText(payload);
    const signature = await crypto.subtle.sign("Ed25519", key.privateKey, textEncoder.encode(text));
    return { payload, publicKey: key.publicKey, signature: base64(signature), signingText: text };
  }

  async function verifySignedRecord(envelope, context, { crypto = root.crypto, currentPublicKey } = {}) {
    if (!envelope?.payload || typeof envelope.signature !== "string" || typeof envelope.publicKey !== "string" ||
        !crypto?.subtle) return null;
    if (currentPublicKey && envelope.publicKey !== currentPublicKey) return null;
    const payload = envelope.payload;
    if (payload.version !== 1 || payload.creator?.profileUrl !== context.profileUrl ||
        payload.context?.provider !== context.externalIdentity?.provider ||
        payload.context?.account !== context.externalIdentity?.account ||
        typeof payload.updatedAt !== "string" || !Number.isFinite(Date.parse(payload.updatedAt)) ||
        !Number.isSafeInteger(payload.sequence) || payload.sequence < 1) return null;
    const profile = app.certifyd?.parseProfileUrl(payload.creator.profileUrl);
    if (!profile || profile.handle !== payload.creator.handle || profile.nodeUrl !== payload.creator.nodeUrl) return null;
    const publicKey = app.ar?.decodePublicKey(envelope.publicKey);
    const signature = app.ar?.decodeSignature(envelope.signature);
    if (!publicKey || !signature) return null;
    try {
      const key = await crypto.subtle.importKey("raw", publicKey, { name: "Ed25519" }, false, ["verify"]);
      const ok = await crypto.subtle.verify("Ed25519", key, signature, textEncoder.encode(signingText(payload)));
      return ok ? envelope : null;
    } catch {
      return null;
    }
  }

  async function mirrorCurrentPublicKey(publicKey, storage) {
    if (!app.ar?.decodePublicKey(publicKey)) throw new Error("Invalid AR public key.");
    await storageSet({ [CURRENT_KEY_ID]: publicKey }, storage);
  }

  async function getCurrentPublicKey(storage) {
    return (await storageGet(CURRENT_KEY_ID, storage))[CURRENT_KEY_ID] || null;
  }

  async function loadEnvelope(context, storage) {
    const id = keyFor({ profileUrl: context.profileUrl, ...context.externalIdentity });
    return (await storageGet(id, storage))[id] || null;
  }

  async function loadVerified(context, options = {}) {
    const envelope = await loadEnvelope(context, options.storage);
    const currentPublicKey = options.currentPublicKey === undefined
      ? await getCurrentPublicKey(options.storage)
      : options.currentPublicKey;
    return verifySignedRecord(envelope, context, { ...options, currentPublicKey });
  }

  async function saveRecord({ page, input, key, connected, storage, crypto = root.crypto, now, minimumSequence } = {}) {
    if (connected !== true) throw new Error("Reconnect this device before saving AR updates.");
    if (!page?.externalIdentity || page.status !== "verified") throw new Error("Open your verified page before saving.");
    const id = keyFor({ profileUrl: page.profileUrl, ...page.externalIdentity });
    const existing = (await storageGet(id, storage))[id];
    const previous = existing?.payload?.sequence;
    const nextLocalSequence = Number.isSafeInteger(previous) ? previous + 1 : 1;
    const nextSequence = Number.isSafeInteger(minimumSequence) && minimumSequence > nextLocalSequence
      ? minimumSequence
      : nextLocalSequence;
    const payload = buildPayload({
      profileUrl: page.profileUrl,
      bundle: page.bundle,
      externalIdentity: page.externalIdentity,
      input,
      sequence: nextSequence,
      now: now || new Date()
    });
    const signed = await signPayload(payload, key, crypto);
    const envelope = {
      id,
      publicKey: signed.publicKey,
      payload: signed.payload,
      signature: signed.signature,
      savedAt: payload.updatedAt
    };
    await storageSet({ [id]: envelope, [CURRENT_KEY_ID]: key.publicKey }, storage);
    return envelope;
  }

  function slotCount(payload) {
    return Object.keys(payload?.slots || {}).length;
  }

  app.arRecord = {
    DOMAIN, CURRENT_KEY_ID, canonicalize, signingText, normalizeSlot, buildPayload, signPayload,
    verifySignedRecord, saveRecord, loadEnvelope, loadVerified, mirrorCurrentPublicKey,
    getCurrentPublicKey, slotCount
  };
  if (typeof module !== "undefined" && module.exports) module.exports = app.arRecord;
})(globalThis);
