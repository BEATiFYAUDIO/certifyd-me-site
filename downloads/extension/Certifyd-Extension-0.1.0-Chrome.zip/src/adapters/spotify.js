(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function artistIdFromUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== "open.spotify.com") return null;
      const match = /^\/artist\/([A-Za-z0-9]{22})\/?$/.exec(url.pathname);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }

  function parseDiscovery(text) {
    if (typeof text !== "string") return null;
    // Spotify may render separate bio lines as a single run of text.
    const proofLabels = [...text.matchAll(/(?:^|\s)Certifyd proof:/g)];
    const profileLabels = [...text.matchAll(/(?:^|\s)Certifyd profile:/g)];
    if (proofLabels.length !== 1 || profileLabels.length !== 1) return null;
    const challenge = /(?:^|\s)Certifyd proof:\s*([0-9a-f]{32})(?=\s|$)/.exec(text);
    const profile = /(?:^|\s)Certifyd profile:\s*(https:\/\/\S+)/.exec(text);
    if (!challenge || !profile) return null;
    const parsed = app.certifyd?.parseProfileUrl(profile[1]);
    if (!parsed) return null;
    return { challenge: `Certifyd proof: ${challenge[1]}`, profileUrl: parsed.profileUrl };
  }

  function findAboutText(doc) {
    const page = doc.querySelector('[data-testid="artist-page"]');
    if (!page) return null;

    // Desktop artist pages expose a single About card with a heading and bio button.
    const cards = [...page.querySelectorAll('[data-testid="grid-container"]')]
      .filter((card) => [...card.querySelectorAll("h2")].some((h) => h.textContent.trim() === "About"));
    if (cards.length > 1) return null;
    if (cards.length === 1) {
      const bio = cards[0].querySelector("button[aria-label]");
      if (bio?.textContent?.trim()) return bio.textContent;
    }

    // Spotify's compact layout puts the same bio in an expandable description.
    const compact = page.querySelectorAll('[data-testid="expandable-description"]');
    return compact.length === 1 ? compact[0].textContent : null;
  }

  function readProfile(doc, url) {
    const account = artistIdFromUrl(url);
    if (!account) return null;
    const page = doc.querySelector('[data-testid="artist-page"]');
    const title = page?.querySelector('[data-testid="entityTitle"], [data-testid="adaptiveEntityTitle"]');
    // Spotify clips the title and constrains the hero height. Place the badge
    // beside the listener count, where it remains visible in narrow layouts.
    let mountTarget = null;
    for (let ancestor = title?.parentElement, depth = 0; ancestor && depth < 8; ancestor = ancestor.parentElement, depth++) {
      const listener = [...(ancestor.querySelectorAll?.('span[aria-hidden="true"]') || [])]
        .find((span) => /\bmonthly listeners\b/i.test(span.textContent || ""));
      if (listener) {
        mountTarget = listener.parentElement;
        break;
      }
    }
    if (!mountTarget) return null;
    const discovery = parseDiscovery(findAboutText(doc));
    if (!discovery) return null;
    return { externalIdentity: { provider: "spotify", account }, discovery, mountTarget };
  }

  function start({ window: win, document: doc, onCandidate }) {
    let timer = null;
    let lastUrl = win.location.href;
    let lastKey = null;
    let lastTarget = null;

    function inspect() {
      timer = null;
      const candidate = readProfile(doc, win.location.href);
      const key = candidate
        ? [candidate.externalIdentity.account, candidate.discovery.challenge, candidate.discovery.profileUrl].join("|")
        : null;
      if (key === lastKey && candidate?.mountTarget === lastTarget) return;
      lastKey = key;
      lastTarget = candidate?.mountTarget || null;
      onCandidate(candidate);
    }

    function schedule() {
      if (timer !== null) return;
      timer = win.setTimeout(inspect, 120);
    }

    const observer = new win.MutationObserver(schedule);
    observer.observe(doc.documentElement, { childList: true, characterData: true, subtree: true });
    const interval = win.setInterval(() => {
      if (lastUrl === win.location.href) return;
      lastUrl = win.location.href;
      schedule();
    }, 700);
    win.addEventListener("popstate", schedule);
    win.addEventListener("hashchange", schedule);
    inspect();

    return () => {
      observer.disconnect();
      win.clearInterval(interval);
      if (timer !== null) win.clearTimeout(timer);
      win.removeEventListener("popstate", schedule);
      win.removeEventListener("hashchange", schedule);
    };
  }

  const adapter = {
    matches: (value) => {
      try {
        const url = new URL(value);
        return url.protocol === "https:" && url.hostname === "open.spotify.com";
      } catch {
        return false;
      }
    },
    start,
    readCurrent: (win, doc) => readProfile(doc, win.location.href)
  };
  app.spotify = { artistIdFromUrl, parseDiscovery, findAboutText, readProfile };
  app.adapters.register(adapter);
  if (typeof module !== "undefined" && module.exports) module.exports = app.spotify;
})(globalThis);
