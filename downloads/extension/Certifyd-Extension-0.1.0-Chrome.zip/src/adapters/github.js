(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  function log(step, details = {}) {
    root.console?.debug?.("[Certifyd AR][GitHub]", step, details);
  }

  const RESERVED = new Set([
    "about", "account", "actions", "apps", "blog", "codespaces", "collections", "contact",
    "customer-stories", "dashboard", "events", "explore", "features", "gist", "help", "issues",
    "join", "login", "logout", "marketplace", "new", "notifications", "organizations",
    "orgs", "pricing", "pulls", "repositories", "search", "security", "settings", "sponsors",
    "topics", "trending"
  ]);

  function normalizeUsername(value) {
    const text = String(value || "").trim().replace(/^@/, "");
    if (!/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(text)) return null;
    const lower = text.toLowerCase();
    return RESERVED.has(lower) ? null : lower;
  }

  function identityFromUrl(value, doc) {
    let url;
    try { url = new URL(value); } catch { return null; }
    if (url.protocol !== "https:" || url.hostname !== "github.com") return null;
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts.length !== 1) return null;
    const account = normalizeUsername(parts[0]);
    if (!account || isOrganizationProfile(doc)) return null;
    return { provider: "github", account, source: "profile-url" };
  }

  function isOrganizationProfile(doc) {
    const type = doc?.querySelector?.('[itemscope][itemtype="http://schema.org/Organization"], [itemscope][itemtype="https://schema.org/Organization"]');
    if (type) return true;
    const hover = doc?.querySelector?.('[data-hovercard-type="organization"]');
    return Boolean(hover);
  }

  function parseDiscovery(text) {
    if (typeof text !== "string") return null;
    const profileLabels = [...text.matchAll(/(?:^|\s)Certifyd profile:/gi)];
    if (profileLabels.length !== 1) return null;
    const profile = /(?:^|\s)Certifyd profile:\s*(https:\/\/\S+)/i.exec(text);
    if (!profile) return null;
    const parsed = app.certifyd?.parseProfileUrl(profile[1]) || app.certifyd?.parseNodeRootUrl?.(profile[1]);
    if (!parsed) return null;

    const modernProofs = [...text.matchAll(/(?:^|\s)Certifyd proof:/gi)];
    const legacyProofs = [...text.matchAll(/(?:^|\s)certifyd-proof\s+provider=github\s+account=([A-Za-z0-9-]{1,39})(?:\s+nonce=([A-Za-z0-9._-]+))?/gi)];
    if (modernProofs.length + legacyProofs.length !== 1) return null;

    const modern = /(?:^|\s)Certifyd proof:\s*([0-9a-f]{32})(?=\s|$)/i.exec(text);
    if (modern) return { challenge: `Certifyd proof: ${modern[1].toLowerCase()}`, profileUrl: parsed.profileUrl || parsed.nodeUrl };
    const legacy = legacyProofs[0];
    const account = normalizeUsername(legacy?.[1]);
    if (!account) return null;
    const nonce = legacy?.[2] ? ` nonce=${legacy[2]}` : "";
    return {
      challenge: `certifyd-proof provider=github account=${account}${nonce}`,
      profileUrl: parsed.profileUrl || parsed.nodeUrl
    };
  }

  function discoveryCandidates(text) {
    const direct = parseDiscovery(text);
    if (direct) return [direct];
    const lines = String(text || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    const candidates = [];
    for (let i = 0; i < lines.length; i += 1) {
      if (!/certifyd-proof\s+provider=github/i.test(lines[i]) && !/^Certifyd proof:/i.test(lines[i])) continue;
      for (let j = Math.max(0, i - 2); j <= Math.min(lines.length - 1, i + 2); j += 1) {
        if (i === j || !/^Certifyd profile:/i.test(lines[j])) continue;
        const first = i < j ? lines[i] : lines[j];
        const second = i < j ? lines[j] : lines[i];
        const parsed = parseDiscovery(`${first}\n${second}`);
        if (parsed) candidates.push(parsed);
      }
    }
    return candidates;
  }

  function discoveryEntries(doc) {
    const scopes = [
      doc?.querySelector?.("main"),
      doc?.querySelector?.("[data-testid='profile-layout']"),
      doc?.querySelector?.(".application-main"),
      doc?.body
    ].filter(Boolean);
    const metaSelectors = [
      'meta[name="description"]',
      'meta[property="og:description"]',
      'meta[name="twitter:description"]'
    ];
    const entries = [];
    const pageText = scopes[0]?.textContent || "";
    if (pageText) entries.push({ source: "rendered-profile-text", text: pageText });
    for (const selector of metaSelectors) {
      const text = doc?.querySelector?.(selector)?.content || "";
      if (text) entries.push({ source: selector, text });
    }
    return entries;
  }

  function decodeEntities(text) {
    return String(text || "")
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&amp;/g, "&");
  }

  function textFromHtml(html) {
    const lines = [];
    const linePattern = /<td\b[^>]*\bclass=["'][^"']*blob-code-inner[^"']*["'][^>]*>([\s\S]*?)<\/td>/gi;
    for (const match of html.matchAll(linePattern)) {
      const stripped = match[1].replace(/<[^>]+>/g, "").trim();
      if (stripped) lines.push(decodeEntities(stripped));
    }
    if (lines.length) return lines.join("\n");
    return decodeEntities(String(html || "").replace(/<[^>]+>/g, " "));
  }

  function safeGistUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== "gist.github.com" || url.username || url.password || url.search || url.hash) return null;
      const parts = url.pathname.split("/").filter(Boolean);
      if (parts.length < 1) return null;
      const owner = normalizeUsername(parts[0]);
      if (!owner) return null;
      url.pathname = parts.length >= 2 ? `/${parts[0]}/${parts[1]}` : `/${parts[0]}`;
      return { href: url.href, owner, ownerPage: parts.length === 1 };
    } catch {
      return null;
    }
  }

  function profileLinks(doc) {
    const links = [];
    const selectors = [
      "a[rel~='me'][href]",
      ".vcard-details a[href]",
      "[itemprop='url'] a[href]",
      "[itemprop='social'] a[href]"
    ];
    for (const selector of selectors) {
      for (const node of doc?.querySelectorAll?.(selector) || []) {
        const href = node.href || node.getAttribute?.("href");
        if (href && !links.includes(href)) links.push(href);
      }
    }
    if (!links.length) {
      for (const node of doc?.querySelectorAll?.("a[href]") || []) {
        const href = node.href || node.getAttribute?.("href");
        if (href && !links.includes(href)) links.push(href);
      }
    }
    return links;
  }

  function candidateProfileReferences(doc) {
    const refs = [];
    const push = (value) => {
      if (typeof value !== "string" || !value.trim()) return;
      if (!refs.includes(value)) refs.push(value);
    };
    for (const href of profileLinks(doc)) {
      try {
        const url = new URL(href, "https://github.com/");
        if (url.protocol !== "https:") continue;
        const direct = app.certifyd?.parseProfileUrl(url.href) || app.certifyd?.parseNodeRootUrl?.(url.href);
        if (direct) push(direct.profileUrl || direct.nodeUrl);
        const host = url.hostname.toLowerCase().replace(/^www\./, "");
        const skipCertifydSubdomain = host.startsWith("certifyd.") || /(^|\.)(githubassets\.com|githubusercontent\.com|github\.com|github\.io|github\.blog|githubstatus\.com|s3\.amazonaws\.com)$/.test(host) || host === "gist.github.com";
        if (host && !skipCertifydSubdomain) push(`https://certifyd.${host}`);
      } catch {}
    }
    return refs;
  }

  function verifiedGithubProof(bundle, account) {
    const proofs = Array.isArray(bundle?.proofs?.social) ? bundle.proofs.social : [];
    return proofs.find((proof) => proof?.provider === "github" &&
      normalizeUsername(proof.account) === account &&
      typeof proof.verifiedAt === "string" && Number.isFinite(Date.parse(proof.verifiedAt)) &&
      safeGistUrl(proof.location));
  }

  async function fetchText(url, fetcher, signal, { accept = "text/html", limit = 512000 } = {}) {
    if (typeof fetcher !== "function") return null;
    try {
      const response = await fetcher(url, {
        method: "GET",
        mode: "cors",
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal,
        headers: { accept }
      });
      if (!response.ok) return null;
      const finalUrl = response.url || url;
      if (new URL(finalUrl).origin !== new URL(url).origin) return null;
      const length = Number(response.headers?.get?.("content-length") || 0);
      if (length > limit) return null;
      const text = await response.text();
      return text.length <= limit ? text : null;
    } catch {
      return null;
    }
  }

  async function fetchTextViaRuntime(url) {
    try {
      const response = await app.arTransportStatic?.sendRuntimeMessage?.({ type: "CERTIFYD_FETCH_PUBLIC_TEXT", url });
      if (!response?.ok) return null;
      return typeof response.text === "string" ? response.text : null;
    } catch {
      return null;
    }
  }

  async function resolveViaCoreLinkedGist(doc, externalIdentity, { fetcher = root.fetch?.bind(root), signal } = {}) {
    if (!externalIdentity || typeof fetcher !== "function") return null;
    const refs = candidateProfileReferences(doc);
    log("gist-fallback:refs", { account: externalIdentity.account, refs });
    for (const ref of refs) {
      const profile = await app.network?.resolveProfileReference?.(ref, fetcher, signal);
      if (!profile) { log("gist-fallback:no-profile", { ref }); continue; }
      log("gist-fallback:profile", { ref, profile });
      const response = await app.network?.fetchProofBundle?.(profile, fetcher, signal);
      if (!response?.ok) { log("gist-fallback:proof-fetch-failed", { ref, reason: response?.reason }); continue; }
      const result = app.certifyd?.comparePublicProof?.({
        provider: "github",
        account: externalIdentity.account,
        profileUrl: profile.profileUrl,
        bundle: response.bundle
      });
      if (result?.status !== "core_reports_verified") { log("gist-fallback:core-mismatch", { ref, status: result?.status }); continue; }
      const proof = verifiedGithubProof(response.bundle, externalIdentity.account);
      const gist = safeGistUrl(proof?.location);
      if (!gist || gist.owner !== externalIdentity.account) { log("gist-fallback:gist-mismatch", { location: proof?.location, gist }); continue; }
      log("gist-fallback:gist", { href: gist.href, ownerPage: gist.ownerPage });
      const html = await fetchText(gist.href, fetcher, signal, { accept: "text/html" }) || await fetchTextViaRuntime(gist.href);
      if (!html) { log("gist-fallback:gist-fetch-failed", { href: gist.href }); continue; }
      const gistText = textFromHtml(html);
      for (const discovery of discoveryCandidates(gistText)) {
        const gistProfile = await app.network?.resolveProfileReference?.(discovery.profileUrl, fetcher, signal);
        if (!gistProfile || gistProfile.profileUrl !== profile.profileUrl || gistProfile.nodeUrl !== profile.nodeUrl) { log("gist-fallback:gist-profile-mismatch", { discovery, gistProfile, profile }); continue; }
        const gistAccount = /(?:^|\s)certifyd-proof\s+provider=github\s+account=([A-Za-z0-9-]{1,39})(?:\s|$)/i.exec(discovery.challenge);
        if (normalizeUsername(gistAccount?.[1]) !== externalIdentity.account) { log("gist-fallback:gist-account-mismatch", { challenge: discovery.challenge }); continue; }
        log("gist-fallback:matched", { profileUrl: gistProfile.profileUrl });
        return { discovery: { ...discovery, profileUrl: gistProfile.profileUrl }, source: "core-linked-gist" };
      }
    }
    return null;
  }

  function findMountTarget(doc) {
    for (const selector of [
      ".vcard-fullname",
      "[itemprop='name']",
      "h1.vcard-names",
      ".vcard-names",
      ".vcard-names-container",
      ".h-card .vcard-names",
      ".h-card",
      "[data-testid='profile-name']",
      "[itemtype='http://schema.org/Person'] h1",
      "[itemtype='https://schema.org/Person'] h1",
      "[itemtype='http://schema.org/Person']",
      "[itemtype='https://schema.org/Person']",
      "main h1",
      "main [data-view-component='true'] h1",
      "main"
    ]) {
      const node = doc?.querySelector?.(selector);
      if (node && node.isConnected !== false) return { node, source: selector };
    }
    return null;
  }

  function directDiscovery(doc) {
    for (const entry of discoveryEntries(doc)) {
      const discovery = parseDiscovery(entry.text);
      if (discovery) return discovery;
    }
    return null;
  }

  function candidateFromDiscovery(externalIdentity, discovery, doc) {
    if (!externalIdentity || !discovery) return null;
    const mount = findMountTarget(doc);
    return {
      externalIdentity: { provider: "github", account: externalIdentity.account },
      discovery,
      mountTarget: mount?.node || null
    };
  }

  function readProfile(doc, url) {
    const externalIdentity = identityFromUrl(url, doc);
    if (!externalIdentity) return null;
    return candidateFromDiscovery(externalIdentity, directDiscovery(doc), doc);
  }

  async function readProfileAsync(doc, url, options = {}) {
    const externalIdentity = identityFromUrl(url, doc);
    if (!externalIdentity) return null;
    const direct = directDiscovery(doc);
    if (direct) {
      const candidate = candidateFromDiscovery(externalIdentity, direct, doc);
      log("readProfile:direct", { account: externalIdentity.account, hasMountTarget: Boolean(candidate?.mountTarget) });
      return candidate;
    }
    const resolved = await resolveViaCoreLinkedGist(doc, externalIdentity, options);
    const candidate = candidateFromDiscovery(externalIdentity, resolved?.discovery, doc);
    log("readProfile:fallback", { account: externalIdentity.account, matched: Boolean(resolved), hasMountTarget: Boolean(candidate?.mountTarget) });
    return candidate;
  }

  function start({ window: win, document: doc, onCandidate }) {
    root.console?.info?.("[Certifyd AR][GitHub] adapter-start", { href: win.location?.href });
    let timer = null;
    let lastUrl = win.location.href;
    let lastKey = null;
    let lastTarget = null;

    let sequence = 0;
    async function inspect() {
      timer = null;
      const request = ++sequence;
      const controller = win.AbortController ? new win.AbortController() : null;
      const candidate = await readProfileAsync(doc, win.location.href, {
        fetcher: win.fetch?.bind(win),
        signal: controller?.signal
      }).catch(() => null);
      if (request !== sequence) return;
      const key = candidate
        ? [candidate.externalIdentity.account, candidate.discovery.challenge, candidate.discovery.profileUrl].join("|")
        : null;
      if (key === lastKey && candidate?.mountTarget === lastTarget) return;
      lastKey = key;
      lastTarget = candidate?.mountTarget || null;
      onCandidate(candidate);
    }

    function schedule() {
      if (timer !== null) return;
      timer = win.setTimeout(inspect, 160);
    }

    const observer = new win.MutationObserver(schedule);
    observer.observe(doc.documentElement, { childList: true, characterData: true, subtree: true });
    const interval = win.setInterval(() => {
      if (lastUrl === win.location.href) return;
      lastUrl = win.location.href;
      schedule();
    }, 700);
    win.addEventListener("popstate", schedule);
    win.addEventListener("hashchange", schedule);
    win.addEventListener("turbo:render", schedule);
    win.addEventListener("turbo:load", schedule);
    win.addEventListener("pjax:end", schedule);
    inspect();

    return () => {
      observer.disconnect();
      win.clearInterval(interval);
      if (timer !== null) win.clearTimeout(timer);
      win.removeEventListener("popstate", schedule);
      win.removeEventListener("hashchange", schedule);
      win.removeEventListener("turbo:render", schedule);
      win.removeEventListener("turbo:load", schedule);
      win.removeEventListener("pjax:end", schedule);
    };
  }

  const adapter = {
    matches: (value) => {
      try {
        const url = new URL(value);
        return url.protocol === "https:" && url.hostname === "github.com";
      } catch {
        return false;
      }
    },
    start,
    readCurrent: (win, doc) => readProfileAsync(doc, win.location.href, { fetcher: win.fetch?.bind(win) })
  };

  app.github = { normalizeUsername, identityFromUrl, parseDiscovery, discoveryCandidates, discoveryEntries, candidateProfileReferences, safeGistUrl, textFromHtml, resolveViaCoreLinkedGist, findMountTarget, readProfile, readProfileAsync };
  app.adapters.register(adapter);
  if (typeof module !== "undefined" && module.exports) module.exports = app.github;
})(globalThis);
