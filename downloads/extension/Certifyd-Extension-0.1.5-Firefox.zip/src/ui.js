(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};
  const mounted = new WeakMap();

  function createBadge(doc, iconUrl) {
    const button = doc.createElement("button");
    button.type = "button";
    button.className = "certifyd-ext__badge";
    button.setAttribute("aria-label", "Certifyd verified — open AR panel");
    button.title = "Certifyd AR";
    if (iconUrl) {
      const icon = doc.createElement("img");
      icon.className = "certifyd-ext__icon";
      icon.src = iconUrl;
      icon.alt = "";
      icon.setAttribute("aria-hidden", "true");
      button.append(icon);
    } else {
      button.textContent = "CERTIFYD ✓";
    }
    button.setAttribute("aria-expanded", "false");
    return button;
  }

  function addActionLink(doc, target, label, href) {
    const link = doc.createElement("a");
    link.className = "certifyd-ext__action";
    link.href = href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = label;
    target.append(link);
    return link;
  }

  function supportHref(value) {
    const text = String(value || "").trim();
    if (/^[^\s@]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(text)) return `lightning:${text}`;
    if (/^(bc1[ac-hj-np-z02-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(text)) return `bitcoin:${text}`;
    return text;
  }

  function invoiceAmountSats(invoice) {
    const match = /^ln(?:bc|tb|bcrt)(\d+)([munp]?)1/i.exec(invoice || "");
    if (!match) return null;
    const factors = { "": 100000000, m: 100000, u: 100, n: 0.1, p: 0.0001 };
    return Number(match[1]) * factors[match[2].toLowerCase()];
  }

  async function fixedAmountInvoice(address, amountSats, fetcher = app.publicFetch || root.fetch?.bind(root)) {
    if (!/^[^\s@]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(address) ||
        !Number.isSafeInteger(amountSats) || amountSats < 1 || amountSats > 100000000 || !fetcher) {
      throw new Error("Invalid fixed-amount Lightning payment.");
    }
    const [name, domain] = address.split("@");
    const endpoint = new URL(`https://${domain}/.well-known/lnurlp/${encodeURIComponent(name)}`);
    const metadataResponse = await fetcher(endpoint.href, { credentials: "omit", redirect: "error" });
    if (!metadataResponse.ok) throw new Error("Wallet address could not be reached.");
    const metadata = await metadataResponse.json();
    const millisats = amountSats * 1000;
    if (metadata.tag !== "payRequest" || millisats < metadata.minSendable || millisats > metadata.maxSendable) {
      throw new Error("This wallet does not accept that sats amount.");
    }
    const callback = new URL(metadata.callback);
    if (callback.protocol !== "https:" || callback.username || callback.password || callback.hash) {
      throw new Error("Wallet returned an invalid payment endpoint.");
    }
    callback.searchParams.set("amount", String(millisats));
    const invoiceResponse = await fetcher(callback.href, { credentials: "omit", redirect: "error" });
    if (!invoiceResponse.ok) throw new Error("Wallet could not create an invoice.");
    const invoice = await invoiceResponse.json();
    if (invoice.status === "ERROR" || !/^ln(bc|tb|bcrt)[a-z0-9]+$/i.test(invoice.pr || "")) {
      throw new Error(invoice.reason || "Wallet returned an invalid invoice.");
    }
    if (invoiceAmountSats(invoice.pr) !== amountSats) throw new Error("Wallet returned an invoice for a different amount.");
    return `lightning:${invoice.pr}`;
  }

  function supportAmountSats(support) {
    if (Number.isSafeInteger(support?.amountSats) && support.amountSats > 0) return support.amountSats;
    const match = /^\s*([1-9][\d,]*)\s+sats?\b/i.exec(support?.label || "");
    if (!match) return null;
    const amount = Number(match[1].replaceAll(",", ""));
    return Number.isSafeInteger(amount) && amount <= 100000000 ? amount : null;
  }

  function cssUrl(value) {
    const text = String(value || "").trim();
    if (!text) return "";
    return `url("${text.replace(/\\/g, "\\\\").replace(/"/g, "%22")}")`;
  }

  function renderArPanelContent(doc, target, { creatorName, payload, iconUrl, profileAssets = {}, onClose } = {}) {
    target.replaceChildren();
    const slots = payload?.slots || {};

    const shell = doc.createElement("span");
    shell.className = "certifyd-ext__ar-shell";

    const close = doc.createElement("button");
    close.type = "button";
    close.className = "certifyd-ext__close";
    close.setAttribute("aria-label", "Close Certifyd AR panel");
    close.textContent = "×";
    close.addEventListener?.("click", () => onClose?.());
    shell.append(close);

    const header = doc.createElement("span");
    header.className = "certifyd-ext__ar-header";
    const brand = doc.createElement("span");
    brand.className = "certifyd-ext__ar-brand";
    const avatarUrl = profileAssets.avatarUrl;
    if (avatarUrl || iconUrl) {
      const icon = doc.createElement("img");
      icon.className = avatarUrl ? "certifyd-ext__ar-logo certifyd-ext__ar-logo--avatar" : "certifyd-ext__ar-logo";
      icon.src = avatarUrl || iconUrl;
      icon.alt = avatarUrl ? `${creatorName || "Creator"} avatar` : "";
      if (!avatarUrl) icon.setAttribute("aria-hidden", "true");
      brand.append(icon);
    } else {
      const mark = doc.createElement("span");
      mark.className = "certifyd-ext__ar-mark";
      mark.setAttribute("aria-hidden", "true");
      mark.textContent = "C";
      brand.append(mark);
    }
    const copy = doc.createElement("span");
    copy.className = "certifyd-ext__ar-copy";
    const official = doc.createElement("span");
    official.className = "certifyd-ext__ar-official";
    official.textContent = "Official from";
    const title = doc.createElement("strong");
    title.className = "certifyd-ext__ar-name";
    title.textContent = creatorName || "this creator";
    const verified = doc.createElement("span");
    verified.className = "certifyd-ext__ar-verified";
    verified.textContent = "Verified Certifyd AR";
    copy.append(official, title, verified);
    header.append(brand, copy);
    shell.append(header);

    const body = doc.createElement("span");
    body.className = "certifyd-ext__ar-body";

    function addSlot({ kind, eyebrow, title, text, actionLabel, href, amountSats, destination }) {
      const section = doc.createElement("span");
      section.className = `certifyd-ext__slot certifyd-ext__slot--${kind}`;
      const slotCopy = doc.createElement("span");
      slotCopy.className = "certifyd-ext__slot-copy";
      const label = doc.createElement("span");
      label.className = "certifyd-ext__slot-label";
      label.textContent = eyebrow;
      const heading = doc.createElement("b");
      heading.className = "certifyd-ext__slot-title";
      heading.textContent = title;
      slotCopy.append(label, heading);
      if (text) {
        const note = doc.createElement("span");
        note.className = "certifyd-ext__note";
        note.textContent = text;
        slotCopy.append(note);
      }
      section.append(slotCopy);
      if (href && actionLabel) {
        const link = addActionLink(doc, section, actionLabel, href);
        if (kind === "support" && amountSats && destination) {
          const prepareInvoice = async () => {
            if (link.dataset?.invoiceLoading === "true") return;
            link.dataset.invoiceLoading = "true";
            link.textContent = `Preparing ${amountSats.toLocaleString()} sat invoice…`;
            try {
              link.href = await fixedAmountInvoice(destination, amountSats);
              link.dataset.invoiceReady = "true";
              link.textContent = `Open ${amountSats.toLocaleString()} sat invoice`;
            } catch (error) {
              link.textContent = "Retry payment";
              link.title = error?.message || "Could not create invoice.";
            } finally {
              delete link.dataset.invoiceLoading;
            }
          };
          link.addEventListener?.("click", (event) => {
            if (link.dataset?.invoiceReady === "true") return;
            event.preventDefault();
            void prepareInvoice();
          });
        }
      }
      body.append(section);
    }

    if (slots.reveal) {
      addSlot({
        kind: "reveal",
        eyebrow: "Reveal",
        title: slots.reveal.title || "Reveal",
        text: slots.reveal.text,
        actionLabel: "Open reveal",
        href: slots.reveal.url
      });
    }
    if (slots.support) {
      addSlot({
        kind: "support",
        eyebrow: "Support",
        title: slots.support.label || "Support this creator",
        actionLabel: slots.support.label || "Support",
        href: supportHref(slots.support.destination),
        amountSats: supportAmountSats(slots.support),
        destination: slots.support.destination
      });
    }
    if (slots.action) {
      addSlot({
        kind: "action",
        eyebrow: "Action",
        title: slots.action.label || "Open action",
        actionLabel: slots.action.label || "Open",
        href: slots.action.url
      });
    }
    if (!slots.reveal && !slots.support && !slots.action) {
      const empty = doc.createElement("span");
      empty.className = "certifyd-ext__empty";
      empty.textContent = "No Certifyd AR actions configured here yet.";
      body.append(empty);
    }
    shell.append(body);
    target.append(shell);
    return target;
  }

  function renderButtonArPanel(doc, target, options = {}) {
    target.classList?.add?.("certifyd-ext__card--ar");
    target.setAttribute?.("data-certifyd-surface", "button-ar-panel");
    const wallpaper = cssUrl(options.profileAssets?.wallpaperUrl);
    if (wallpaper) {
      if (target.style?.setProperty) target.style.setProperty("--creator-wallpaper", wallpaper);
      else if (target.style) target.style["--creator-wallpaper"] = wallpaper;
    }
    return renderArPanelContent(doc, target, options);
  }

  function renderPromotionCard(doc, target, { creatorName, payload, profileAssets = {} } = {}) {
    const promotion = payload?.slots?.promotion;
    if (!promotion || promotion.active !== true || !promotion.headline || !promotion.offer ||
        !promotion.description || !promotion.destination) return false;
    target.replaceChildren();
    target.classList?.add?.("certifyd-promotion-card");
    target.setAttribute?.("data-certifyd-surface", "sovereign-promotion");
    const wallpaper = cssUrl(profileAssets.wallpaperUrl);
    if (wallpaper) {
      if (target.style?.setProperty) target.style.setProperty("--creator-wallpaper", wallpaper);
      else if (target.style) target.style["--creator-wallpaper"] = wallpaper;
    }
    const eyebrow = doc.createElement("span");
    eyebrow.className = "certifyd-promotion-card__eyebrow";
    eyebrow.textContent = `From ${creatorName || "this creator"}`;
    const title = doc.createElement("h2");
    title.className = "certifyd-promotion-card__headline";
    title.textContent = promotion.headline;
    const description = doc.createElement("p");
    description.className = "certifyd-promotion-card__description";
    description.textContent = promotion.description;
    const action = doc.createElement("a");
    action.className = "certifyd-promotion-card__action";
    action.href = promotion.destination;
    action.target = "_blank";
    action.rel = "noopener noreferrer";
    action.textContent = promotion.offer;
    target.append(eyebrow, title, description, action);
    return true;
  }

  function mount(target, details = {}, doc = target?.ownerDocument) {
    if (!target || !doc) throw new TypeError("A DOM target is required");
    const previous = mounted.get(target);
    if (previous) return previous;

    const container = doc.createElement("span");
    container.className = "certifyd-ext";
    const badge = createBadge(doc, details.iconUrl);
    const panel = doc.createElement("span");
    panel.className = "certifyd-ext__card";
    panel.hidden = true;
    function close() {
      panel.hidden = true;
      badge.setAttribute("aria-expanded", "false");
    }
    renderButtonArPanel(doc, panel, {
      creatorName: details.name,
      payload: details.arPayload,
      iconUrl: details.iconUrl,
      profileAssets: details.profileAssets,
      onClose: close
    });
    const view = doc.defaultView || root;
    function positionPanel() {
      if (panel.hidden || !badge.getBoundingClientRect) return;
      const anchor = badge.getBoundingClientRect();
      const bounds = panel.getBoundingClientRect();
      const width = view.innerWidth || doc.documentElement?.clientWidth || 1024;
      const height = view.innerHeight || doc.documentElement?.clientHeight || 768;
      const gap = 8;
      const edge = 12;
      const left = Math.max(edge, Math.min(anchor.left, width - bounds.width - edge));
      const below = anchor.bottom + gap;
      const top = below + bounds.height <= height - edge
        ? below
        : Math.max(edge, anchor.top - bounds.height - gap);
      panel.style.left = `${Math.round(left)}px`;
      panel.style.top = `${Math.round(top)}px`;
    }
    function onClick(event) {
      if (!container.contains(event.target) && !panel.contains(event.target)) close();
    }
    function onKeydown(event) {
      if (event.key === "Escape") close();
    }
    function onBadgeClick() {
      panel.hidden = !panel.hidden;
      badge.setAttribute("aria-expanded", String(!panel.hidden));
      positionPanel();
    }
    badge.addEventListener("click", onBadgeClick);
    doc.addEventListener("click", onClick);
    doc.addEventListener("keydown", onKeydown);
    doc.addEventListener("scroll", positionPanel, true);
    view.addEventListener?.("resize", positionPanel);
    container.append(badge);
    target.append(container);
    (doc.body || doc.documentElement).append(panel);

    function remove() {
      badge.removeEventListener("click", onBadgeClick);
      doc.removeEventListener("click", onClick);
      doc.removeEventListener("keydown", onKeydown);
      doc.removeEventListener("scroll", positionPanel, true);
      view.removeEventListener?.("resize", positionPanel);
      panel.remove();
      container.remove();
      mounted.delete(target);
    }
    mounted.set(target, remove);
    return remove;
  }

  app.ui = { createBadge, renderButtonArPanel, renderPromotionCard, supportHref, fixedAmountInvoice, supportAmountSats, mount };
  if (typeof module !== "undefined" && module.exports) module.exports = app.ui;
})(globalThis);
