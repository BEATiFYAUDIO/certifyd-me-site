(function (root) {
  const runtime = root.browser?.runtime || root.chrome?.runtime;
  if (!runtime?.onMessage) return;

  function isAllowedPublicTextUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password || url.port) return false;
      if (url.hostname === "gist.github.com") return true;
      if (url.hostname === "beatifyaudio.github.io" && url.pathname.startsWith("/certifyd-ar-registry/")) return true;
      if (isPublicHost(url.hostname) && (/^\/u\/[a-z0-9_-]{1,64}(?:\/proofs\.json)?\/?$/i.test(url.pathname) || url.pathname === "/")) return true;
      if (isPublicHost(url.hostname) && /^\/\.well-known\/lnurlp\/[a-z0-9_-]+$/i.test(url.pathname)) return true;
      if (isPublicHost(url.hostname) && url.searchParams.has("amount") && /\/lnurl\//i.test(url.pathname)) return true;
      return false;
    } catch {
      return false;
    }
  }

  function isPublicHost(host) {
    return host.includes(".") && !host.endsWith(".local") && !host.endsWith(".localhost") &&
      !/^\d+(?:\.\d+){3}$/.test(host) && !host.includes(":");
  }

  function isAllowedImageUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol === "chrome-extension:" && url.href === runtime.getURL("icons/certifyd-mark-32.png")) return true;
      return url.protocol === "https:" && !url.username && !url.password && !url.port && isPublicHost(url.hostname) &&
        /^\/public\/(?:profile-wallpapers|avatars)\//.test(url.pathname);
    } catch { return false; }
  }

  async function fetchPublicText(url) {
    if (!isAllowedPublicTextUrl(url)) return { ok: false, reason: "url_not_allowed" };
    const response = await fetch(url, {
      method: "GET",
      credentials: "omit",
      redirect: "error",
      cache: "no-store",
      headers: { accept: "text/html, application/json" }
    });
    const finalUrl = response.url || url;
    if (new URL(finalUrl).origin !== new URL(url).origin) return { ok: false, reason: "redirected" };
    const length = Number(response.headers?.get?.("content-length") || 0);
    if (length > 512000) return { ok: false, reason: "too_large" };
    const text = await response.text();
    if (text.length > 512000) return { ok: false, reason: "too_large" };
    return { ok: response.ok, status: response.status, url: finalUrl, text,
      contentType: response.headers.get("content-type") || "", contentLength: length || text.length };
  }

  async function fetchPublicImage(url) {
    if (!isAllowedImageUrl(url)) return { ok: false, reason: "url_not_allowed" };
    const response = await fetch(url, { credentials: "omit", redirect: "error", cache: "no-store" });
    const type = response.headers.get("content-type") || "";
    const length = Number(response.headers.get("content-length") || 0);
    if (!response.ok || !/^image\/(?:png|jpeg|webp|gif|svg\+xml)\b/i.test(type) || length > 2000000) return { ok: false, reason: "invalid_image" };
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.length > 2000000) return { ok: false, reason: "too_large" };
    let binary = "";
    for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return { ok: true, dataUrl: `data:${type};base64,${btoa(binary)}` };
  }

  runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "CERTIFYD_FETCH_PUBLIC_TEXT" && message?.type !== "CERTIFYD_FETCH_PUBLIC_IMAGE") return false;
    (message.type === "CERTIFYD_FETCH_PUBLIC_IMAGE" ? fetchPublicImage(message.url) : fetchPublicText(message.url))
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, reason: "fetch_failed", message: String(error?.message || error) }));
    return true;
  });
})(globalThis);
