(function (root) {
  const app = root.CertifydExtension = root.CertifydExtension || {};

  async function publicFetch(url, options = {}) {
    if (options.signal?.aborted) throw new DOMException("Aborted", "AbortError");
    const result = await app.arTransportStatic.sendRuntimeMessage({ type: "CERTIFYD_FETCH_PUBLIC_TEXT", url: String(url) });
    if (options.signal?.aborted) throw new DOMException("Aborted", "AbortError");
    if (!result || result.reason) throw new Error(result?.reason || "Public fetch failed");
    return {
      ok: result.ok === true,
      status: result.status,
      url: result.url,
      headers: { get(name) {
        if (String(name).toLowerCase() === "content-type") return result.contentType || "";
        if (String(name).toLowerCase() === "content-length") return String(result.contentLength || 0);
        return null;
      } },
      text: async () => result.text,
      json: async () => JSON.parse(result.text)
    };
  }

  async function publicImage(url) {
    if (!url) return null;
    const result = await app.arTransportStatic.sendRuntimeMessage({ type: "CERTIFYD_FETCH_PUBLIC_IMAGE", url: String(url) });
    return result?.ok && /^data:image\//.test(result.dataUrl || "") ? result.dataUrl : null;
  }

  app.publicFetch = publicFetch;
  app.publicImage = publicImage;
})(globalThis);
